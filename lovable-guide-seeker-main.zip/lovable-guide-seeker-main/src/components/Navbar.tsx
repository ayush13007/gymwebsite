
import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "./ui/button";
import { NavigationMenu, NavigationMenuItem, NavigationMenuLink, NavigationMenuList, navigationMenuTriggerStyle } from "./ui/navigation-menu";
import { ChevronDown, Dumbbell } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <header className="w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <Dumbbell className="h-6 w-6 text-primary" />
          <span className="text-xl font-bold">FitSpace</span>
        </Link>
        
        <NavigationMenu className="hidden md:flex">
          <NavigationMenuList>
            <NavigationMenuItem>
              <Link to="/" className={navigationMenuTriggerStyle()}>
                Home
              </Link>
            </NavigationMenuItem>
            <NavigationMenuItem>
              <DropdownMenu>
                <DropdownMenuTrigger className={navigationMenuTriggerStyle()}>
                  <div className="flex items-center gap-1">
                    Features <ChevronDown className="h-4 w-4" />
                  </div>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="center" className="w-56">
                  <DropdownMenuItem asChild>
                    <Link to="/features/premium-gyms">Premium Gyms</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/features/explore-3d">Virtual Tours</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/features/easy-booking">Easy Booking</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/features/fitness-tracking">Fitness Tracking</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/features/community">Community</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/features/secure-payments">Secure Payments</Link>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </NavigationMenuItem>
            <NavigationMenuItem>
              <Link to="/gyms" className={navigationMenuTriggerStyle()}>
                Find Gyms
              </Link>
            </NavigationMenuItem>
            <NavigationMenuItem>
              <Link to="/fitness-features" className={navigationMenuTriggerStyle()}>
                Fitness Hub
              </Link>
            </NavigationMenuItem>
            <NavigationMenuItem>
              <Link to="/blog" className={navigationMenuTriggerStyle()}>
                Blog
              </Link>
            </NavigationMenuItem>
          </NavigationMenuList>
        </NavigationMenu>
        
        <div className="flex items-center gap-4">
          <Link to="/login">
            <Button variant="outline">Sign In</Button>
          </Link>
          <Link to="/register" className="hidden md:block">
            <Button>Join Now</Button>
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
