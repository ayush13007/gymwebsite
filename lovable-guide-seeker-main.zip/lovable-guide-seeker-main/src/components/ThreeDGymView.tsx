
import React, { useEffect, useRef } from 'react';
import { Gym } from '@/types/gym';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface ThreeDGymViewProps {
  gym?: Gym;
}

// More realistic gym textures
const textureURLs = {
  floor: 'https://images.unsplash.com/photo-1575361204480-aadea25e6e68?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8Z3ltJTIwZmxvb3J8ZW58MHx8MHx8fDA%3D',
  wall: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8Z3ltJTIwd2FsbHxlbnwwfHwwfHx8MA%3D%3D',
  equipment: 'https://images.unsplash.com/photo-1638536532686-d610adff3c8c?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTV8fGd5bSUyMGVxdWlwbWVudHxlbnwwfHwwfHx8MA%3D%3D'
};

const ThreeDGymView: React.FC<ThreeDGymViewProps> = ({ gym }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const texturesRef = useRef<{[key: string]: THREE.Texture | null}>({
    floor: null,
    wall: null,
    equipment: null
  });

  useEffect(() => {
    if (!containerRef.current) return;

    // Initialize Three.js scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x111111);

    // Add fog to the scene for depth perception
    scene.fog = new THREE.FogExp2(0x111111, 0.05);

    // Load textures
    const textureLoader = new THREE.TextureLoader();
    Object.entries(textureURLs).forEach(([key, url]) => {
      textureLoader.load(url, texture => {
        texture.wrapS = THREE.RepeatWrapping;
        texture.wrapT = THREE.RepeatWrapping;
        if (key === 'floor') {
          texture.repeat.set(5, 5);
        } else {
          texture.repeat.set(2, 2);
        }
        texturesRef.current[key] = texture;
        
        // Once all textures are loaded, update materials
        if (Object.values(texturesRef.current).every(tex => tex !== null)) {
          updateMaterials();
        }
      });
    });

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      75,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.z = 15;
    camera.position.y = 5;
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    renderer.shadowMap.enabled = true;
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(5, 10, 7);
    directionalLight.castShadow = true;
    directionalLight.shadow.camera.far = 50;
    directionalLight.shadow.mapSize.set(1024, 1024);
    scene.add(directionalLight);

    const pointLight = new THREE.PointLight(0xff9900, 1, 100);
    pointLight.position.set(-5, 8, 10);
    scene.add(pointLight);

    // Floor
    const floorGeometry = new THREE.PlaneGeometry(50, 50);
    const floorMaterial = new THREE.MeshStandardMaterial({ 
      color: 0x333333, 
      roughness: 0.8,
      metalness: 0.2,
    });
    const floor = new THREE.Mesh(floorGeometry, floorMaterial);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -2;
    floor.receiveShadow = true;
    scene.add(floor);

    // Walls - create a room
    const wallMaterial = new THREE.MeshStandardMaterial({
      color: 0x444444,
      roughness: 0.7,
      metalness: 0.3
    });
    
    // Back wall
    const backWallGeometry = new THREE.BoxGeometry(50, 20, 1);
    const backWall = new THREE.Mesh(backWallGeometry, wallMaterial);
    backWall.position.set(0, 8, -25);
    backWall.receiveShadow = true;
    scene.add(backWall);
    
    // Side walls
    const sideWallGeometry = new THREE.BoxGeometry(1, 20, 50);
    const leftWall = new THREE.Mesh(sideWallGeometry, wallMaterial);
    leftWall.position.set(-25, 8, 0);
    leftWall.receiveShadow = true;
    scene.add(leftWall);
    
    const rightWall = new THREE.Mesh(sideWallGeometry, wallMaterial);
    rightWall.position.set(25, 8, 0);
    rightWall.receiveShadow = true;
    scene.add(rightWall);

    // Example gym equipment
    addGymEquipment(scene);

    // Add OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2;
    controlsRef.current = controls;

    // Function to update materials with loaded textures
    function updateMaterials() {
      if (texturesRef.current.floor) {
        floor.material = new THREE.MeshStandardMaterial({
          map: texturesRef.current.floor,
          roughness: 0.8,
          metalness: 0.2,
        });
      }
      if (texturesRef.current.wall) {
        const wallMaterialWithTexture = new THREE.MeshStandardMaterial({
          map: texturesRef.current.wall,
          roughness: 0.7,
          metalness: 0.3
        });
        backWall.material = wallMaterialWithTexture;
        leftWall.material = wallMaterialWithTexture;
        rightWall.material = wallMaterialWithTexture;
      }
    }

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);
      if (controlsRef.current) controlsRef.current.update();
      rendererRef.current?.render(sceneRef.current as THREE.Scene, cameraRef.current as THREE.PerspectiveCamera);
    };
    animate();

    // Handle window resize
    const handleResize = () => {
      if (!containerRef.current || !cameraRef.current || !rendererRef.current) return;
      
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;
      
      cameraRef.current.aspect = width / height;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(width, height);
    };
    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      if (containerRef.current && rendererRef.current) {
        containerRef.current.removeChild(rendererRef.current.domElement);
      }
      rendererRef.current?.dispose();
      // Dispose of geometries and materials here as needed
    };
  }, []);

  // Function to add gym equipment to the scene
  const addGymEquipment = (scene: THREE.Scene) => {
    // Treadmill
    const treadmillBase = new THREE.BoxGeometry(3, 0.5, 6);
    const treadmillMaterial = new THREE.MeshStandardMaterial({ color: 0x222222 });
    const treadmill = new THREE.Mesh(treadmillBase, treadmillMaterial);
    treadmill.position.set(-6, -0.75, 0);
    treadmill.castShadow = true;
    treadmill.receiveShadow = true;
    scene.add(treadmill);

    // Weights rack
    const rackGeometry = new THREE.BoxGeometry(5, 4, 1);
    const rackMaterial = new THREE.MeshStandardMaterial({ color: 0x444444 });
    const rack = new THREE.Mesh(rackGeometry, rackMaterial);
    rack.position.set(6, 0, -5);
    rack.castShadow = true;
    rack.receiveShadow = true;
    scene.add(rack);

    // Dumbbells
    for (let i = 0; i < 5; i++) {
      const dumbbellGeometry = new THREE.CylinderGeometry(0.3, 0.3, 0.8, 16);
      const dumbbellMaterial = new THREE.MeshStandardMaterial({ 
        color: Math.random() > 0.5 ? 0x666666 : 0x888888,
        metalness: 0.7,
        roughness: 0.2
      });
      const dumbbell = new THREE.Mesh(dumbbellGeometry, dumbbellMaterial);
      dumbbell.position.set(5.5 + (i % 2), 0.5 + Math.floor(i / 2) * 1.2, -4.5);
      dumbbell.rotation.x = Math.PI / 2;
      dumbbell.castShadow = true;
      scene.add(dumbbell);
    }

    // Bench press
    const benchGeometry = new THREE.BoxGeometry(1.5, 0.5, 4);
    const benchMaterial = new THREE.MeshStandardMaterial({ color: 0x000000 });
    const bench = new THREE.Mesh(benchGeometry, benchMaterial);
    bench.position.set(0, -0.75, 0);
    bench.castShadow = true;
    bench.receiveShadow = true;
    scene.add(bench);

    // Barbell
    const barbellGeometry = new THREE.CylinderGeometry(0.1, 0.1, 6, 16);
    const barbellMaterial = new THREE.MeshStandardMaterial({ 
      color: 0x888888,
      metalness: 0.8,
      roughness: 0.1
    });
    const barbell = new THREE.Mesh(barbellGeometry, barbellMaterial);
    barbell.position.set(0, 1, 0);
    barbell.rotation.z = Math.PI / 2;
    barbell.castShadow = true;
    scene.add(barbell);
    
    // Weight plates on the barbell
    const plateGeometry = new THREE.CylinderGeometry(0.4, 0.4, 0.1, 32);
    const plateMaterial = new THREE.MeshStandardMaterial({ color: 0x333333, metalness: 0.6, roughness: 0.3 });
    
    // Left plates
    const leftPlate1 = new THREE.Mesh(plateGeometry, plateMaterial);
    leftPlate1.position.set(-2.2, 1, 0);
    leftPlate1.rotation.z = Math.PI / 2;
    scene.add(leftPlate1);
    
    const leftPlate2 = new THREE.Mesh(plateGeometry, plateMaterial);
    leftPlate2.position.set(-2.5, 1, 0);
    leftPlate2.rotation.z = Math.PI / 2;
    scene.add(leftPlate2);
    
    // Right plates
    const rightPlate1 = new THREE.Mesh(plateGeometry, plateMaterial);
    rightPlate1.position.set(2.2, 1, 0);
    rightPlate1.rotation.z = Math.PI / 2;
    scene.add(rightPlate1);
    
    const rightPlate2 = new THREE.Mesh(plateGeometry, plateMaterial);
    rightPlate2.position.set(2.5, 1, 0);
    rightPlate2.rotation.z = Math.PI / 2;
    scene.add(rightPlate2);
    
    // Exercise balls
    const ballGeometry = new THREE.SphereGeometry(1, 32, 32);
    const ballMaterial1 = new THREE.MeshStandardMaterial({ color: 0xff3333, roughness: 0.8 });
    const ball1 = new THREE.Mesh(ballGeometry, ballMaterial1);
    ball1.position.set(-8, 0, -5);
    ball1.castShadow = true;
    scene.add(ball1);
    
    const ballMaterial2 = new THREE.MeshStandardMaterial({ color: 0x3333ff, roughness: 0.8 });
    const ball2 = new THREE.Mesh(ballGeometry, ballMaterial2);
    ball2.position.set(-6, 0, -7);
    ball2.castShadow = true;
    scene.add(ball2);
    
    // Mirrors on the wall
    const mirrorGeometry = new THREE.BoxGeometry(15, 10, 0.1);
    const mirrorMaterial = new THREE.MeshStandardMaterial({ 
      color: 0xffffff, 
      metalness: 0.9,
      roughness: 0.1,
      envMapIntensity: 1.0
    });
    const mirror = new THREE.Mesh(mirrorGeometry, mirrorMaterial);
    mirror.position.set(0, 5, -24.5);
    scene.add(mirror);
  };

  return (
    <div className="flex flex-col">
      <div ref={containerRef} className="w-full h-[500px] rounded-lg overflow-hidden mb-4"></div>
      
      {gym && (
        <div className="grid gap-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>{gym.name}</CardTitle>
              <CardDescription>
                <div className="flex items-center gap-2">
                  <span>{gym.location}</span>
                  {gym.rating && (
                    <Badge className="bg-primary">{gym.rating} ★</Badge>
                  )}
                </div>
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p>{gym.description || "No description available"}</p>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button>Book Now</Button>
              <Button variant="outline">Contact</Button>
            </CardFooter>
          </Card>
        </div>
      )}
    </div>
  );
};

export default ThreeDGymView;
