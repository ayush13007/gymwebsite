
import React, { useState, useRef, useEffect } from 'react';
import { Send, Minimize2, Maximize2, X, Bot, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { motion, AnimatePresence } from 'framer-motion';
import { useChatbot } from '@/hooks/useChatbot';
import { cn } from '@/lib/utils';

export interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

const ChatbotUI = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [message, setMessage] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  
  const { 
    messages, 
    isLoading, 
    sendMessage, 
    clearMessages,
  } = useChatbot();

  useEffect(() => {
    // Scroll to bottom on new messages
    if (bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    if (!message.trim()) return;
    
    try {
      await sendMessage(message);
      setMessage('');
    } catch (error) {
      console.error('Failed to send message:', error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    }
    
    // Focus the input after sending
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const toggleChat = () => {
    setIsOpen(!isOpen);
    setIsMinimized(false);
    
    // Small delay to focus input after animation completes
    if (!isOpen) {
      setTimeout(() => {
        if (inputRef.current) inputRef.current.focus();
      }, 300);
    }
  };

  const toggleMinimize = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsMinimized(!isMinimized);
  };

  const handleClose = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsOpen(false);
  };

  return (
    <>
      {/* Chat button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            className="fixed bottom-4 right-4 z-50"
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Button 
              onClick={toggleChat} 
              size="lg"
              className="h-14 w-14 rounded-full bg-gradient-to-r from-primary to-purple-600 shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <Bot className="h-6 w-6" />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ 
              opacity: 1, 
              y: 0, 
              scale: 1,
              height: isMinimized ? 'auto' : '70vh',
              width: isMinimized ? 'auto' : '380px'
            }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-4 right-4 z-50 shadow-2xl"
          >
            <Card className="border-2 border-primary/20 overflow-hidden h-full bg-gradient-to-b from-background to-background/95 backdrop-blur-lg">
              {/* Header */}
              <CardHeader className="bg-gradient-to-r from-primary to-purple-600 text-white p-3 flex flex-row items-center justify-between space-x-0">
                <div className="flex items-center gap-2" onClick={toggleChat}>
                  <Bot className="h-5 w-5" />
                  <h3 className="font-medium">GymZone Assistant</h3>
                  <Badge variant="outline" className="border-white/30 bg-white/10 text-white text-xs">
                    AI
                  </Badge>
                </div>
                <div className="flex items-center space-x-1">
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-white hover:bg-white/20 rounded-full" onClick={toggleMinimize}>
                    {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
                  </Button>
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-white hover:bg-white/20 rounded-full" onClick={handleClose}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>

              {/* Messages */}
              <AnimatePresence>
                {!isMinimized && (
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: 'auto' }}
                    exit={{ height: 0 }}
                  >
                    <ScrollArea className="h-[calc(70vh-130px)] p-4">
                      <div className="space-y-4">
                        {messages.length === 0 ? (
                          <div className="flex flex-col items-center justify-center h-32 text-center p-4">
                            <Bot className="h-10 w-10 text-primary mb-2" />
                            <h3 className="text-lg font-medium">GymZone AI Assistant</h3>
                            <p className="text-muted-foreground text-sm mt-1">
                              Ask me anything about workouts, gyms, or booking help!
                            </p>
                          </div>
                        ) : (
                          messages.map((msg) => (
                            <motion.div
                              key={msg.id}
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              className={cn(
                                "flex items-start gap-3",
                                msg.role === "user" ? "flex-row-reverse" : "flex-row"
                              )}
                            >
                              <Avatar className={cn(
                                "h-8 w-8",
                                msg.role === "user" 
                                  ? "bg-primary text-white" 
                                  : "bg-muted text-primary"
                              )}>
                                <AvatarFallback>
                                  {msg.role === "user" ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                                </AvatarFallback>
                              </Avatar>
                              
                              <div className={cn(
                                "rounded-lg px-3 py-2 max-w-[80%] text-sm",
                                msg.role === "user"
                                  ? "bg-primary text-primary-foreground"
                                  : "bg-muted"
                              )}>
                                {msg.content}
                                <div className="text-xs opacity-50 mt-1">
                                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </div>
                              </div>
                            </motion.div>
                          ))
                        )}
                        {isLoading && (
                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="flex items-start gap-3"
                          >
                            <Avatar className="h-8 w-8 bg-muted text-primary">
                              <AvatarFallback>
                                <Bot className="h-4 w-4" />
                              </AvatarFallback>
                            </Avatar>
                            <div className="bg-muted rounded-lg px-4 py-2">
                              <div className="flex space-x-1 items-center h-5">
                                <div className="w-2 h-2 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: '0ms' }}></div>
                                <div className="w-2 h-2 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: '150ms' }}></div>
                                <div className="w-2 h-2 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: '300ms' }}></div>
                              </div>
                            </div>
                          </motion.div>
                        )}
                        <div ref={bottomRef} />
                      </div>
                    </ScrollArea>

                    {/* Footer */}
                    <CardFooter className="border-t p-3 gap-2">
                      <form onSubmit={handleSendMessage} className="flex w-full gap-2">
                        <Input
                          ref={inputRef}
                          placeholder="Ask about workouts, bookings, or gyms..."
                          value={message}
                          onChange={(e) => setMessage(e.target.value)}
                          disabled={isLoading}
                          className="flex-1"
                        />
                        <Button 
                          type="submit" 
                          size="icon"
                          disabled={isLoading || !message.trim()}
                          className="shrink-0"
                        >
                          <Send className="h-4 w-4" />
                        </Button>
                      </form>
                    </CardFooter>
                  </motion.div>
                )}
              </AnimatePresence>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default ChatbotUI;
