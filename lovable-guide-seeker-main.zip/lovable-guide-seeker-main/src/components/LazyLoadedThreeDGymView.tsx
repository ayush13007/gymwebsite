
import React, { Suspense } from 'react';
import { Gym } from '@/types/gym';

// Lazy load the ThreeDGymView component
const ThreeDGymView = React.lazy(() => import('./ThreeDGymView'));

interface LazyLoadedThreeDGymViewProps {
  gym?: Gym;
}

const LazyLoadedThreeDGymView: React.FC<LazyLoadedThreeDGymViewProps> = ({ gym }) => {
  return (
    <Suspense fallback={
      <div className="flex items-center justify-center w-full h-full bg-zinc-900 min-h-[400px] rounded-lg">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-red-500 mx-auto mb-4"></div>
          <p className="text-lg font-medium text-white">Loading 3D view...</p>
          <p className="text-sm text-gray-400">Please wait while we prepare your experience</p>
        </div>
      </div>
    }>
      <ThreeDGymView gym={gym} />
    </Suspense>
  );
};

export default LazyLoadedThreeDGymView;
