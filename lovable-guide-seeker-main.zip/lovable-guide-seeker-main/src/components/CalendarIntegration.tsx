
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { toast } from "@/components/ui/sonner";
import { Calendar as CalendarIcon, CalendarClock, CalendarPlus } from "lucide-react";

const CalendarIntegration = () => {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [isConnected, setIsConnected] = useState(false);
  
  const connectGoogleCalendar = () => {
    // This would typically use OAuth to connect to Google Calendar
    // For demo purposes, we'll simulate a successful connection
    setTimeout(() => {
      setIsConnected(true);
      toast("Connected to Google Calendar", {
        description: "You can now schedule gym sessions and receive reminders.",
      });
    }, 1500);
  };
  
  const scheduleWorkout = () => {
    if (!date) return;
    
    // In a real app, this would create an event in Google Calendar
    // For demo purposes, we'll just show a success message
    toast("Workout scheduled", {
      description: `Your workout has been scheduled for ${date.toLocaleDateString()} and added to your Google Calendar.`,
    });
  };
  
  const setReminder = () => {
    if (!date) return;
    
    // In a real app, this would set a reminder in Google Calendar
    // For demo purposes, we'll just show a success message
    toast("Reminder set", {
      description: `You will receive a reminder before your workout on ${date.toLocaleDateString()}.`,
    });
  };

  return (
    <div className="py-8 bg-muted">
      <div className="container">
        <h2 className="text-3xl font-bold mb-8 text-center">Schedule Your Workouts</h2>
        
        <div className="grid md:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalendarIcon className="h-5 w-5" />
                Select Date
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex justify-center p-4">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  className="rounded-md border"
                />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Google Calendar Integration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {!isConnected ? (
                <Button onClick={connectGoogleCalendar} className="w-full">
                  Connect Google Calendar
                </Button>
              ) : (
                <div className="space-y-4">
                  <p className="text-center text-green-600 font-medium">
                    Connected to Google Calendar
                  </p>
                  
                  <Button 
                    onClick={scheduleWorkout} 
                    className="w-full flex items-center justify-center gap-2"
                    disabled={!date}
                  >
                    <CalendarPlus className="h-4 w-4" />
                    Schedule Workout
                  </Button>
                  
                  <Button
                    onClick={setReminder}
                    variant="outline"
                    className="w-full flex items-center justify-center gap-2"
                    disabled={!date}
                  >
                    <CalendarClock className="h-4 w-4" />
                    Set Reminder
                  </Button>
                  
                  <div className="text-sm text-muted-foreground mt-4">
                    <p>Benefits of calendar integration:</p>
                    <ul className="list-disc pl-5 mt-2">
                      <li>Never miss a workout session</li>
                      <li>Get reminders before your workout</li>
                      <li>Track your gym attendance</li>
                      <li>Sync with your other appointments</li>
                    </ul>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CalendarIntegration;
