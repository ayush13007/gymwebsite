
import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom'; // Import jest-dom for DOM assertion matchers
import FitnessTracking from './FitnessTracking';

// Mock the toast function
jest.mock('@/components/ui/sonner', () => ({
  toast: jest.fn(),
}));

describe('FitnessTracking Component', () => {
  it('renders the connect button when not connected', () => {
    render(<FitnessTracking />);
    
    expect(screen.getByText('Connect Google Fit')).toBeInTheDocument();
    expect(screen.getByText('Connect your Google Fit account to track your workouts, steps, heart rate, and more.')).toBeInTheDocument();
  });
  
  it('connects to Google Fit when button is clicked', async () => {
    render(<FitnessTracking />);
    
    const connectButton = screen.getByText('Connect Google Fit');
    fireEvent.click(connectButton);
    
    // Wait for the connection to complete (simulated by the setTimeout)
    await waitFor(() => {
      expect(screen.getByText('8,432')).toBeInTheDocument();
      expect(screen.getByText('steps today')).toBeInTheDocument();
      expect(screen.getByText('420')).toBeInTheDocument();
      expect(screen.getByText('active calories')).toBeInTheDocument();
      expect(screen.getByText('72')).toBeInTheDocument();
      expect(screen.getByText('beats per minute')).toBeInTheDocument();
      expect(screen.getByText('45')).toBeInTheDocument();
      expect(screen.getByText('minutes today')).toBeInTheDocument();
    }, { timeout: 2000 });
  });
});
