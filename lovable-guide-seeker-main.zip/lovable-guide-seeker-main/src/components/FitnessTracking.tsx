
import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/components/ui/sonner";
import { Activity, Heart, RotateCcw, Smartphone, TrendingUp, Dumbbell } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAppSelector, useAppDispatch } from "@/hooks/redux";
import { connectFitnessService, fetchHealthData } from "@/store/slices/healthSlice";
import { Progress } from "@/components/ui/progress";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

// Constants for unit conversion
const CONVERSION = {
  MILES_TO_KM: 1.60934,
  LBS_TO_KG: 0.453592,
};

const FitnessTracking = () => {
  const dispatch = useAppDispatch();
  const { data: healthData, isConnected, loading } = useAppSelector(state => state.health);
  const [selectedService, setSelectedService] = useState<string>("googlefit");
  const [refreshing, setRefreshing] = useState(false);
  const [useMetric, setUseMetric] = useState(true); // Default to metric system (kg, km)
  const [weeklyActivity, setWeeklyActivity] = useState([]);

  // Function to handle unit conversion
  const convertUnits = useCallback((value: number, type: 'distance' | 'weight') => {
    if (!useMetric) return value; // Return as-is if already in metric
    return type === 'distance' 
      ? (value * CONVERSION.MILES_TO_KM).toFixed(1) 
      : (value * CONVERSION.LBS_TO_KG).toFixed(1);
  }, [useMetric]);

  // Format activity data for display
  const formatActivityData = useCallback(() => {
    if (!isConnected) return [];
    
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return days.map((day, i) => {
      const today = new Date().getDay();
      const isToday = (i + 1) % 7 === today ? true : false;
      
      // Generate more realistic looking data with a trend
      const baseActivity = healthData.workoutMinutes / 2;
      const activityMinutes = Math.floor(baseActivity + (Math.random() * baseActivity * 0.8));
      const caloriesBurned = Math.floor(activityMinutes * 5 + Math.random() * 100);
      
      return {
        day,
        activityMinutes,
        caloriesBurned,
        target: 60,
        isToday
      };
    });
  }, [isConnected, healthData]);

  useEffect(() => {
    // Auto-refresh data every 60 seconds if connected
    let interval: NodeJS.Timeout;
    if (isConnected) {
      interval = setInterval(() => {
        refreshHealthData();
      }, 60000);
      
      // Set weekly activity data
      setWeeklyActivity(formatActivityData());
    }
    return () => clearInterval(interval);
  }, [isConnected, formatActivityData]);

  const handleConnect = async () => {
    try {
      await dispatch(connectFitnessService(selectedService)).unwrap();
      toast("Connected to fitness service", {
        description: `Your ${getServiceName(selectedService)} data has been synced.`,
        icon: "✅",
      });
      setWeeklyActivity(formatActivityData());
    } catch (error) {
      toast("Connection failed", {
        description: "Could not connect to fitness service. Please try again.",
        style: { backgroundColor: "#f87171", color: "white" },
      });
    }
  };

  const refreshHealthData = async () => {
    if (!isConnected) return;
    
    setRefreshing(true);
    try {
      await dispatch(fetchHealthData()).unwrap();
      setWeeklyActivity(formatActivityData());
      toast("Data refreshed", {
        description: "Your health data has been updated.",
        icon: "🔄",
      });
    } catch (error) {
      toast("Refresh failed", {
        description: "Could not update health data. Please try again.",
        style: { backgroundColor: "#f87171", color: "white" },
      });
    } finally {
      setRefreshing(false);
    }
  };

  const getServiceName = (serviceId: string): string => {
    const serviceMap: Record<string, string> = {
      googlefit: "Google Fit",
      applehealth: "Apple Health",
      fitbit: "Fitbit",
      garmin: "Garmin",
      samsunghealth: "Samsung Health",
      strava: "Strava"
    };
    return serviceMap[serviceId] || serviceId;
  };

  const getServiceIcon = (serviceId: string) => {
    const iconMap: Record<string, any> = {
      googlefit: Activity,
      applehealth: Heart,
      fitbit: Smartphone,
      garmin: Activity,
      samsunghealth: Smartphone,
      strava: TrendingUp
    };
    return iconMap[serviceId] || Activity;
  };

  const fitnessServices = [
    { id: "googlefit", name: "Google Fit", icon: Activity },
    { id: "applehealth", name: "Apple Health", icon: Heart },
    { id: "fitbit", name: "Fitbit", icon: Smartphone },
    { id: "garmin", name: "Garmin", icon: Activity },
    { id: "samsunghealth", name: "Samsung Health", icon: Smartphone },
    { id: "strava", name: "Strava", icon: TrendingUp },
  ];

  const calculateProgressPercentage = (current: number, target: number): number => {
    return Math.min(Math.round((current / target) * 100), 100);
  };

  return (
    <div className="py-12">
      <div className="container">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold text-center">Track Your Fitness Progress</h2>
          {isConnected && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setUseMetric(!useMetric)}
              className="flex items-center gap-1"
            >
              {useMetric ? "Switch to Imperial (mi, lb)" : "Switch to Metric (km, kg)"}
            </Button>
          )}
        </div>
        
        {!isConnected ? (
          <Card className="max-w-3xl mx-auto">
            <CardHeader>
              <CardTitle className="text-center">Connect Fitness Services</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-6 text-muted-foreground text-center">
                Connect your fitness account to track your workouts, steps, heart rate, and more.
              </p>
              
              <Tabs defaultValue={selectedService} onValueChange={setSelectedService}>
                <TabsList className="grid grid-cols-3 md:grid-cols-6 mb-6">
                  {fitnessServices.map((service) => (
                    <TabsTrigger key={service.id} value={service.id}>
                      <div className="flex flex-col items-center gap-1">
                        <service.icon className="h-4 w-4" />
                        <span className="text-xs">{service.name}</span>
                      </div>
                    </TabsTrigger>
                  ))}
                </TabsList>
                
                {fitnessServices.map((service) => (
                  <TabsContent key={service.id} value={service.id} className="text-center">
                    <img 
                      src={`https://via.placeholder.com/120x120/1a1a1a/ffffff?text=${service.name}`}
                      alt={service.name}
                      className="w-16 h-16 mx-auto mb-4 rounded-full" 
                    />
                    <p className="mb-6">
                      {service.name} helps you track your activities, steps, heart rate, and more.
                      Connect your account to start tracking your fitness journey.
                    </p>
                    <Button 
                      onClick={handleConnect}
                      className="flex items-center gap-2"
                      disabled={loading}
                    >
                      {loading ? (
                        <>
                          <span className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-2" />
                          Connecting...
                        </>
                      ) : (
                        <>
                          <service.icon className="h-4 w-4" />
                          Connect {service.name}
                        </>
                      )}
                    </Button>
                  </TabsContent>
                ))}
              </Tabs>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-8">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                {getServiceIcon(selectedService)({ className: "h-5 w-5 text-primary" })}
                <span className="font-medium">Connected to {getServiceName(selectedService)}</span>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={refreshHealthData}
                disabled={refreshing}
                className="flex items-center gap-1"
              >
                <RotateCcw className={`h-3.5 w-3.5 ${refreshing ? 'animate-spin' : ''}`} />
                <span>{refreshing ? 'Refreshing...' : 'Refresh Data'}</span>
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-center text-lg">Daily Steps</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-4xl font-bold mb-2">{healthData.steps.toLocaleString()}</div>
                  <p className="text-muted-foreground">steps today</p>
                  <div className="mt-4">
                    <Progress value={calculateProgressPercentage(healthData.steps, 10000)} className="h-2" />
                  </div>
                  <p className="text-xs mt-1 text-muted-foreground">
                    {calculateProgressPercentage(healthData.steps, 10000)}% of daily goal (10,000)
                  </p>
                  <p className="text-xs mt-2 text-primary">
                    {useMetric 
                      ? `≈ ${(healthData.steps * 0.0008).toFixed(2)} km` 
                      : `≈ ${(healthData.steps * 0.0005).toFixed(2)} miles`}
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-center text-lg">Calories Burned</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-4xl font-bold mb-2">{healthData.calories}</div>
                  <p className="text-muted-foreground">active calories</p>
                  <div className="mt-4">
                    <Progress value={calculateProgressPercentage(healthData.calories, 600)} className="h-2 bg-gray-200">
                      <div className="h-full bg-orange-500 rounded-full"></div>
                    </Progress>
                  </div>
                  <p className="text-xs mt-1 text-muted-foreground">
                    {calculateProgressPercentage(healthData.calories, 600)}% of daily goal (600)
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-center text-lg">Heart Rate</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="flex items-center justify-center mb-2">
                    <Heart className="h-6 w-6 text-red-500 fill-red-500 mr-2 animate-pulse" />
                    <span className="text-4xl font-bold">{healthData.heartRate}</span>
                  </div>
                  <p className="text-muted-foreground">beats per minute</p>
                  <div className="mt-4 flex justify-center items-center gap-2 text-xs">
                    <span className="text-blue-400">Resting <span className="text-muted-foreground">(60-70)</span></span>
                    <div className="h-1.5 w-1.5 rounded-full bg-blue-400"></div>
                    <span className="text-green-400">Active <span className="text-muted-foreground">(71-90)</span></span>
                    <div className="h-1.5 w-1.5 rounded-full bg-green-400"></div>
                    <span className="text-red-400">Peak <span className="text-muted-foreground">(91+)</span></span>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-center text-lg">Workout Time</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-4xl font-bold mb-2">{healthData.workoutMinutes}</div>
                  <p className="text-muted-foreground">minutes today</p>
                  <div className="mt-4">
                    <Progress value={calculateProgressPercentage(healthData.workoutMinutes, 60)} className="h-2" />
                  </div>
                  <p className="text-xs mt-1 text-muted-foreground">
                    {calculateProgressPercentage(healthData.workoutMinutes, 60)}% of daily goal (60 min)
                  </p>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Weekly Activity</CardTitle>
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <div className="h-3 w-3 rounded-full bg-primary mr-1"></div>
                    <span>Activity (minutes)</span>
                  </div>
                  <div className="flex items-center">
                    <div className="h-3 w-3 rounded-full bg-orange-400 mr-1"></div>
                    <span>Calories (×10)</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="h-60">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={weeklyActivity}
                    margin={{ top: 10, right: 10, left: 0, bottom: 20 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.1} />
                    <XAxis 
                      dataKey="day"
                      tickLine={false}
                      axisLine={false}
                      tick={{ fontSize: 12 }}
                    />
                    <YAxis 
                      tickLine={false}
                      axisLine={false}
                      tick={{ fontSize: 12 }}
                      width={30}
                    />
                    <Tooltip 
                      formatter={(value, name) => {
                        if (name === "caloriesBurned") return [`${value} cal`, "Calories"];
                        return [`${value} min`, "Activity"];
                      }}
                    />
                    <Bar 
                      dataKey="activityMinutes"
                      fill="currentColor"
                      className="fill-primary"
                      radius={[4, 4, 0, 0]}
                      barSize={20}
                    />
                    <Bar 
                      dataKey="caloriesBurned"
                      fill="currentColor"
                      className="fill-orange-400"
                      radius={[4, 4, 0, 0]}
                      barSize={20}
                      // Scale calories to compare with minutes
                      tickFormatter={(value) => value / 10}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default FitnessTracking;
