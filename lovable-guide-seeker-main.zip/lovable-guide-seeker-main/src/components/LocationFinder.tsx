
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "@/components/ui/sonner";
import { MapPin, Navigation } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface Gym {
  id: number;
  name: string;
  distance: number;
  address: string;
  rating: string;
  image: string;
}

const LocationFinder = () => {
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [loading, setLoading] = useState(false);
  const [nearbyGyms, setNearbyGyms] = useState<Gym[]>([]);

  const findUserLocation = () => {
    setLoading(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
          fetchNearbyGyms(position.coords.latitude, position.coords.longitude);
          setLoading(false);
          toast("Location found successfully", {
            description: `Latitude: ${position.coords.latitude.toFixed(4)}, Longitude: ${position.coords.longitude.toFixed(4)}`,
          });
        },
        (error) => {
          console.error("Error getting location:", error);
          setLoading(false);
          toast("Could not access your location", {
            description: "Please check your browser permissions and try again.",
          });
        }
      );
    } else {
      setLoading(false);
      toast("Geolocation not supported", {
        description: "Your browser does not support location services.",
      });
    }
  };

  const fetchNearbyGyms = (lat: number, lng: number) => {
    // In a real app, this would be an API call to fetch nearby gyms
    // For demo purposes, we'll use mock data
    const mockGyms: Gym[] = [
      {
        id: 1,
        name: "Fitness Paradise",
        distance: 0.5,
        address: "123 Gym Street",
        rating: "4.9",
        image: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
      },
      {
        id: 2,
        name: "Elite Training Center",
        distance: 1.2,
        address: "456 Fitness Avenue",
        rating: "4.7",
        image: "https://images.unsplash.com/photo-1540497077202-7c8a3999166f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
      },
      {
        id: 3,
        name: "Power Gym",
        distance: 1.8,
        address: "789 Strength Road",
        rating: "4.5",
        image: "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
      },
    ];
    setNearbyGyms(mockGyms);
  };

  return (
    <div className="py-8">
      <div className="container">
        <h2 className="text-3xl font-bold mb-6 text-center">Find Gyms Near You</h2>
        <div className="flex justify-center mb-8">
          <Button 
            onClick={findUserLocation} 
            disabled={loading} 
            className="flex items-center gap-2"
          >
            <Navigation className="h-4 w-4" />
            {loading ? "Locating..." : "Use My Current Location"}
          </Button>
        </div>
        
        {location && (
          <div className="mb-8 text-center">
            <p className="text-muted-foreground">
              Your location: {location.lat.toFixed(4)}, {location.lng.toFixed(4)}
            </p>
          </div>
        )}
        
        {nearbyGyms.length > 0 && (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {nearbyGyms.map((gym) => (
              <Card key={gym.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="h-48 overflow-hidden">
                  <img
                    src={gym.image}
                    alt={gym.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardHeader className="pb-2">
                  <CardTitle>{gym.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{gym.distance} miles away</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-yellow-500">★</span>
                      <span>{gym.rating}</span>
                    </div>
                  </div>
                  <p className="text-muted-foreground mb-4">{gym.address}</p>
                  <Button className="w-full">Book Now</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default LocationFinder;
