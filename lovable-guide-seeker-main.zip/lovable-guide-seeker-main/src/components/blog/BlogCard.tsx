
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { formatDistanceToNow } from "date-fns";

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  image: string;
  author: {
    name: string;
    avatar: string;
  };
  publishedAt: Date;
  category: string;
  readTime: number;
}

interface BlogCardProps {
  post: BlogPost;
}

const BlogCard = ({ post }: BlogCardProps) => {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="aspect-video relative overflow-hidden">
        <img
          src={post.image}
          alt={post.title}
          className="object-cover w-full h-full hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
          {post.category}
        </div>
      </div>
      <CardHeader className="py-4">
        <Link to={`/blog/${post.id}`} className="hover:text-primary transition-colors">
          <h3 className="text-xl font-bold line-clamp-2">{post.title}</h3>
        </Link>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground line-clamp-3">{post.excerpt}</p>
      </CardContent>
      <CardFooter className="flex items-center justify-between text-sm text-muted-foreground pt-0">
        <div className="flex items-center">
          <img
            src={post.author.avatar}
            alt={post.author.name}
            className="w-6 h-6 rounded-full mr-2"
          />
          <span>{post.author.name}</span>
        </div>
        <div className="flex items-center gap-2">
          <span>{formatDistanceToNow(post.publishedAt, { addSuffix: true })}</span>
          <span>·</span>
          <span>{post.readTime} min read</span>
        </div>
      </CardFooter>
    </Card>
  );
};

export default BlogCard;
