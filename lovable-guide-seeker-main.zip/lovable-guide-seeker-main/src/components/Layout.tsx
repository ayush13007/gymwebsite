
import { useEffect } from "react";
import { Outlet } from "react-router-dom";
import Navbar from "./Navbar";
import Footer from "./Footer";
import ChatbotUI from "./ChatBot/ChatbotUI";
import { setupBarba } from "@/utils/setupBarba";
import { toast } from "@/components/ui/sonner";

const Layout = () => {
  useEffect(() => {
    // Setup Barba.js for page transitions
    try {
      const timer = setTimeout(() => {
        setupBarba();
      }, 100); // Give time for DOM to fully render
      
      return () => clearTimeout(timer);
    } catch (error) {
      console.error("Error setting up Barba.js:", error);
    }

    // Welcome toast for first-time visitors
    if (!localStorage.getItem("visitedBefore")) {
      setTimeout(() => {
        toast("Welcome to GymZone", {
          description: "Discover your perfect fitness experience",
          duration: 5000,
        });
        localStorage.setItem("visitedBefore", "true");
      }, 2000);
    }
  }, []);

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-background to-background/95" data-barba="wrapper">
      <Navbar />
      <main className="flex-1">
        <div data-barba="container" data-barba-namespace="default" className="page-transition">
          <Outlet />
        </div>
      </main>
      <Footer />
      <ChatbotUI />
    </div>
  );
};

export default Layout;
