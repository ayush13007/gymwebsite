
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Star, MessageSquare } from "lucide-react";

interface Review {
  id: string;
  name: string;
  avatar: string;
  rating: number;
  comment: string;
  date: string;
  likes: number;
  replies: number;
  isVerified: boolean;
}

// Function to generate a set of reviews
const generateReviews = (count: number, startIndex = 0): Review[] => {
  const firstNames = [
    "James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph",
    "Thomas", "Charles", "Mary", "Patricia", "Jennifer", "Linda", "Elizabeth",
    "Barbara", "Susan", "Jessica", "Sarah", "Karen"
  ];
  
  const lastNames = [
    "Smith", "Johnson", "Williams", "Jones", "Brown", "Davis", "Miller", "Wilson",
    "Moore", "Taylor", "Anderson", "Thomas", "Jackson", "White", "Harris",
    "Martin", "Thompson", "Garcia", "Martinez", "Robinson"
  ];
  
  const comments = [
    "Great gym with excellent equipment. The staff is very friendly and helpful.",
    "I've been a member for over a year now and I couldn't be happier with the facilities.",
    "Love the classes they offer, especially the HIIT sessions!",
    "Clean, well-maintained, and never too crowded. Perfect for my workout routine.",
    "The personal trainers really know their stuff and have helped me reach my fitness goals.",
    "Amazing atmosphere and community feel. Everyone is supportive of each other.",
    "Best gym I've ever been to! The 24/7 access is super convenient for my schedule.",
    "The app makes booking classes and tracking my workouts so easy.",
    "Reasonable membership fees for the quality of equipment and services offered.",
    "I appreciate how they're always updating and adding new equipment.",
    "The locker rooms are always clean and well-stocked.",
    "Great variety of equipment - never have to wait for machines.",
    "The fitness assessment when you join is really helpful for setting goals.",
    "I love the smoothie bar - perfect for post-workout nutrition!",
    "The gym has a great community feel - I've made several friends here.",
    "Excellent location with plenty of parking available.",
    "The virtual classes during lockdown were so helpful - glad they kept those options!",
    "Friendly staff who remember your name and make you feel welcome.",
    "Clean, spacious, and modern facilities with great equipment.",
    "Worth every penny of the membership fee!"
  ];
  
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const currentYear = new Date().getFullYear();
  
  return Array.from({ length: count }, (_, i) => {
    const index = i + startIndex;
    const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
    const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
    const randomMonth = months[Math.floor(Math.random() * months.length)];
    const randomDay = Math.floor(Math.random() * 28) + 1;
    const randomRating = Math.floor(Math.random() * 2) + 4; // Ratings between 4-5
    const randomComment = comments[Math.floor(Math.random() * comments.length)];
    
    return {
      id: `review-${index}`,
      name: `${firstName} ${lastName}`,
      avatar: `https://i.pravatar.cc/150?u=${firstName.toLowerCase()}${index}`,
      rating: randomRating,
      comment: randomComment,
      date: `${randomMonth} ${randomDay}, ${currentYear}`,
      likes: Math.floor(Math.random() * 50),
      replies: Math.floor(Math.random() * 10),
      isVerified: Math.random() > 0.3 // 70% chance of being verified
    };
  });
};

// Initial set of reviews (can be expanded to show "200k+" as mentioned by loading more)
const initialReviews = generateReviews(12);

const ReviewsSection = () => {
  const [reviews, setReviews] = useState<Review[]>(initialReviews);
  const [page, setPage] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  
  const loadMoreReviews = () => {
    setIsLoading(true);
    // Simulate API call delay
    setTimeout(() => {
      const newReviews = generateReviews(12, page * 12);
      setReviews([...reviews, ...newReviews]);
      setPage(page + 1);
      setIsLoading(false);
    }, 800);
  };
  
  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold">Community Reviews</h2>
          <p className="text-muted-foreground">
            Over 200,000 reviews from our fitness community
          </p>
        </div>
        <div className="flex items-center">
          <div className="flex">
            {[1, 2, 3, 4, 5].map(star => (
              <Star 
                key={star} 
                fill="currentColor" 
                className="w-5 h-5 text-yellow-500" 
              />
            ))}
          </div>
          <span className="ml-2 font-medium">4.8/5</span>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {reviews.map((review) => (
          <Card key={review.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10 mr-3">
                    <AvatarImage src={review.avatar} alt={review.name} />
                    <AvatarFallback>{review.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center">
                      <span className="font-medium">{review.name}</span>
                      {review.isVerified && (
                        <span className="ml-2 bg-green-100 text-green-600 text-xs px-1.5 py-0.5 rounded">
                          Verified
                        </span>
                      )}
                    </div>
                    <div className="flex text-yellow-500 mt-1">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          fill={i < review.rating ? "currentColor" : "none"} 
                          className="w-3 h-3" 
                        />
                      ))}
                      <span className="text-xs text-muted-foreground ml-2">{review.date}</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <p className="text-sm mb-4">{review.comment}</p>
              
              <div className="flex items-center text-sm text-muted-foreground">
                <button className="flex items-center hover:text-primary transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                    <path d="M7 10v12"></path><path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z"></path>
                  </svg>
                  <span>{review.likes}</span>
                </button>
                <span className="mx-2">•</span>
                <button className="flex items-center hover:text-primary transition-colors">
                  <MessageSquare className="w-3 h-3 mr-1" />
                  <span>{review.replies}</span>
                </button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <div className="flex justify-center">
        <Button
          variant="outline"
          onClick={loadMoreReviews}
          disabled={isLoading}
          className="min-w-[200px]"
        >
          {isLoading ? 'Loading...' : 'Load More Reviews'}
        </Button>
      </div>
    </div>
  );
};

export default ReviewsSection;
