
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Heart, ActivitySquare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface HealthCheckItem {
  id: string;
  label: string;
  checked: boolean;
}

const HealthCheck: React.FC = () => {
  const { toast } = useToast();
  const [healthItems, setHealthItems] = useState<HealthCheckItem[]>([
    { id: "back-pain", label: "Back Pain", checked: false },
    { id: "joint-pain", label: "Joint Pain", checked: false },
    { id: "muscle-strain", label: "Muscle Strain", checked: false },
    { id: "headaches", label: "Frequent Headaches", checked: false },
    { id: "fatigue", label: "Chronic Fatigue", checked: false },
    { id: "sleep", label: "Sleep Problems", checked: false },
    { id: "digestion", label: "Digestive Issues", checked: false },
    { id: "stress", label: "High Stress Levels", checked: false },
  ]);

  const toggleItem = (id: string) => {
    setHealthItems(healthItems.map(item => 
      item.id === id ? { ...item, checked: !item.checked } : item
    ));
  };

  const handleSubmit = () => {
    const checkedItems = healthItems.filter(item => item.checked);
    
    if (checkedItems.length === 0) {
      toast({
        title: "Great Health Status",
        description: "You seem to be in good health! Keep it up with regular exercise.",
        variant: "default",
      });
    } else {
      toast({
        title: `${checkedItems.length} health concerns identified`,
        description: "Our trainers will customize a program addressing your specific needs.",
        variant: checkedItems.length > 3 ? "destructive" : "default",
      });
    }
  };

  return (
    <Card className="shadow-lg">
      <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
        <div className="flex items-center gap-2">
          <Heart className="w-6 h-6" />
          <CardTitle>Health Check</CardTitle>
        </div>
        <CardDescription className="text-gray-100">
          Identify any health concerns before starting your fitness journey
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {healthItems.map((item) => (
            <div key={item.id} className="flex items-start space-x-2">
              <Checkbox 
                id={item.id} 
                checked={item.checked}
                onCheckedChange={() => toggleItem(item.id)}
              />
              <Label
                htmlFor={item.id}
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                {item.label}
              </Label>
            </div>
          ))}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between border-t pt-4">
        <div className="flex items-center text-sm text-gray-500">
          <ActivitySquare className="w-4 h-4 mr-1" />
          <span>All information is confidential</span>
        </div>
        <Button onClick={handleSubmit}>
          Submit Health Check
        </Button>
      </CardFooter>
    </Card>
  );
};

export default HealthCheck;
