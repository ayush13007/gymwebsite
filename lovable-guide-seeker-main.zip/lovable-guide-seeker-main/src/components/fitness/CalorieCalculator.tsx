
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

const CalorieCalculator = () => {
  const [age, setAge] = useState<number>(30);
  const [gender, setGender] = useState<string>("male");
  const [height, setHeight] = useState<number>(170);
  const [weight, setWeight] = useState<number>(70);
  const [activityLevel, setActivityLevel] = useState<string>("moderate");
  const [calories, setCalories] = useState<number | null>(null);
  const { toast } = useToast();

  const calculateCalories = () => {
    if (age <= 0 || height <= 0 || weight <= 0) {
      toast({
        title: "Invalid Input",
        description: "Age, height and weight must be positive values",
        variant: "destructive"
      });
      return;
    }

    // Harris-Benedict Equation
    let bmr = 0;
    if (gender === "male") {
      bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age);
    } else {
      bmr = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age);
    }

    // Activity multiplier
    let activityMultiplier = 1.2; // Sedentary
    if (activityLevel === "light") {
      activityMultiplier = 1.375;
    } else if (activityLevel === "moderate") {
      activityMultiplier = 1.55;
    } else if (activityLevel === "active") {
      activityMultiplier = 1.725;
    } else if (activityLevel === "veryActive") {
      activityMultiplier = 1.9;
    }

    const dailyCalories = Math.round(bmr * activityMultiplier);
    setCalories(dailyCalories);

    toast({
      title: "Calories Calculated",
      description: `Your estimated daily calorie need is ${dailyCalories} calories`
    });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-gradient-primary">Calorie Calculator</CardTitle>
        <CardDescription>Calculate your daily calorie needs</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="age">Age</Label>
            <Input
              id="age"
              type="number"
              value={age}
              onChange={(e) => setAge(parseInt(e.target.value) || 0)}
            />
          </div>
          
          <div className="space-y-2">
            <Label>Gender</Label>
            <RadioGroup value={gender} onValueChange={setGender} className="flex gap-4">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="male" id="male" />
                <Label htmlFor="male">Male</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="female" id="female" />
                <Label htmlFor="female">Female</Label>
              </div>
            </RadioGroup>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="height">Height (cm)</Label>
            <Input
              id="height"
              type="number"
              value={height}
              onChange={(e) => setHeight(parseInt(e.target.value) || 0)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="weight">Weight (kg)</Label>
            <Input
              id="weight"
              type="number"
              value={weight}
              onChange={(e) => setWeight(parseInt(e.target.value) || 0)}
            />
          </div>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="activityLevel">Activity Level</Label>
          <Select value={activityLevel} onValueChange={setActivityLevel}>
            <SelectTrigger>
              <SelectValue placeholder="Select activity level" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="sedentary">Sedentary (little or no exercise)</SelectItem>
              <SelectItem value="light">Light (1-3 days/week)</SelectItem>
              <SelectItem value="moderate">Moderate (3-5 days/week)</SelectItem>
              <SelectItem value="active">Active (6-7 days/week)</SelectItem>
              <SelectItem value="veryActive">Very Active (physical job or 2x training)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <Button onClick={calculateCalories} className="w-full">Calculate Calories</Button>
        
        {calories !== null && (
          <div className="mt-4 p-4 bg-primary/10 rounded-lg text-center">
            <p className="text-lg font-bold">{calories} calories/day</p>
            <div className="grid grid-cols-3 gap-2 mt-2">
              <div className="bg-green-100 dark:bg-green-900/30 p-2 rounded">
                <p className="text-xs">Weight Loss</p>
                <p className="font-bold">{Math.round(calories * 0.8)}</p>
              </div>
              <div className="bg-blue-100 dark:bg-blue-900/30 p-2 rounded">
                <p className="text-xs">Maintenance</p>
                <p className="font-bold">{calories}</p>
              </div>
              <div className="bg-purple-100 dark:bg-purple-900/30 p-2 rounded">
                <p className="text-xs">Weight Gain</p>
                <p className="font-bold">{Math.round(calories * 1.2)}</p>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CalorieCalculator;
