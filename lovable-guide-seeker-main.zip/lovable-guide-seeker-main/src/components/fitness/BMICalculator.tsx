
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";

const BMICalculator = () => {
  const [height, setHeight] = useState<number>(170);
  const [weight, setWeight] = useState<number>(70);
  const [bmi, setBmi] = useState<number | null>(null);
  const [bmiCategory, setBmiCategory] = useState<string>("");
  const { toast } = useToast();

  const calculateBMI = () => {
    if (height <= 0 || weight <= 0) {
      toast({
        title: "Invalid Input",
        description: "Height and weight must be positive values",
        variant: "destructive"
      });
      return;
    }

    const heightInMeters = height / 100;
    const bmiValue = weight / (heightInMeters * heightInMeters);
    setBmi(parseFloat(bmiValue.toFixed(1)));
    
    // Determine BMI category
    if (bmiValue < 18.5) {
      setBmiCategory("Underweight");
    } else if (bmiValue >= 18.5 && bmiValue < 25) {
      setBmiCategory("Normal weight");
    } else if (bmiValue >= 25 && bmiValue < 30) {
      setBmiCategory("Overweight");
    } else {
      setBmiCategory("Obese");
    }

    toast({
      title: "BMI Calculated",
      description: `Your BMI is ${bmiValue.toFixed(1)}`
    });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-gradient-primary">BMI Calculator</CardTitle>
        <CardDescription>Calculate your Body Mass Index</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <label className="block text-sm font-medium">Height (cm): {height}</label>
          <Slider
            value={[height]}
            min={120}
            max={220}
            step={1}
            onValueChange={(value) => setHeight(value[0])}
            className="w-full"
          />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-medium">Weight (kg): {weight}</label>
          <Slider
            value={[weight]}
            min={30}
            max={200}
            step={1}
            onValueChange={(value) => setWeight(value[0])}
            className="w-full"
          />
        </div>
        <Button onClick={calculateBMI} className="w-full">Calculate BMI</Button>
        
        {bmi !== null && (
          <div className="mt-4 p-4 bg-primary/10 rounded-lg text-center">
            <p className="text-lg font-bold">Your BMI: {bmi}</p>
            <p className="text-sm">Category: <span className="font-semibold">{bmiCategory}</span></p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default BMICalculator;
