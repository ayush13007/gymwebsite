
// Re-export the use-toast hook from the hooks directory
import { useToast, toast } from "@/hooks/use-toast";

export { useToast, toast };
