
import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { gsap } from 'gsap';

const ThreeJsHero = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const animationFrameId = useRef<number>(0);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    if (!containerRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x111827, 0.08);
    
    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      70,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.z = 5;
    
    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ 
      antialias: true,
      alpha: true 
    });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setClearColor(0x111827, 0.1);
    containerRef.current.appendChild(renderer.domElement);
    
    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 2);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(1, 1, 1);
    scene.add(directionalLight);

    const spotLight = new THREE.SpotLight(0x9b87f5, 2);
    spotLight.position.set(-10, 10, 10);
    spotLight.castShadow = true;
    scene.add(spotLight);
    
    // Create particles for background effect
    const particleGeometry = new THREE.BufferGeometry();
    const particleCount = 1000;
    const posArray = new Float32Array(particleCount * 3);
    
    for (let i = 0; i < particleCount * 3; i += 3) {
      posArray[i] = (Math.random() - 0.5) * 20;
      posArray[i+1] = (Math.random() - 0.5) * 20;
      posArray[i+2] = (Math.random() - 0.5) * 20;
    }
    
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
    const particleMaterial = new THREE.PointsMaterial({
      size: 0.02,
      color: 0x9b87f5,
      transparent: true,
      opacity: 0.8,
      blending: THREE.AdditiveBlending
    });
    
    const particleSystem = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particleSystem);
    
    // Creating gym-themed objects
    const geometries = [
      new THREE.TorusGeometry(1, 0.3, 16, 50), // Like a weight ring
      new THREE.BoxGeometry(0.8, 0.8, 0.8),    // Like a workout box step
      new THREE.SphereGeometry(0.6, 32, 32),   // Like a fitness ball
      new THREE.CylinderGeometry(0.4, 0.4, 1.2, 32), // Like a dumbbell
    ];
    
    const objects: THREE.Mesh[] = [];
    const colors = [0x9b87f5, 0x7e69ab, 0x6e59a5, 0xd6bcfa, 0xab87e5];
    
    // Create multiple objects scattered in the scene
    for (let i = 0; i < 20; i++) {
      const geometry = geometries[Math.floor(Math.random() * geometries.length)];
      const material = new THREE.MeshPhongMaterial({
        color: colors[Math.floor(Math.random() * colors.length)],
        shininess: 100,
        reflectivity: 1,
      });
      
      const object = new THREE.Mesh(geometry, material);
      
      // Position randomly but within view
      object.position.x = (Math.random() - 0.5) * 10;
      object.position.y = (Math.random() - 0.5) * 10;
      object.position.z = (Math.random() - 0.5) * 5;
      
      // Random rotation
      object.rotation.x = Math.random() * 2 * Math.PI;
      object.rotation.y = Math.random() * 2 * Math.PI;
      object.rotation.z = Math.random() * 2 * Math.PI;
      
      // Scale variety
      const scale = 0.3 + Math.random() * 0.7;
      object.scale.set(scale, scale, scale);
      
      scene.add(object);
      objects.push(object);
      
      // Add initial animation for each object
      gsap.from(object.position, {
        x: 0,
        y: 0,
        z: -10,
        duration: 2,
        delay: i * 0.1,
        ease: "back.out(1.7)",
      });
    }
    
    // Animation function
    const animate = () => {
      animationFrameId.current = requestAnimationFrame(animate);
      
      // Rotate each object
      objects.forEach((obj, i) => {
        obj.rotation.x += 0.01 * (i % 3 === 0 ? 1 : -1);
        obj.rotation.y += 0.01 * (i % 2 === 0 ? 1 : -1);
        
        // Add slight movement
        obj.position.y += Math.sin(Date.now() * 0.001 + i) * 0.002;
      });
      
      // Rotate the particle system slowly
      particleSystem.rotation.y += 0.0003;
      
      // Slowly rotate the camera around
      const time = Date.now() * 0.0005;
      camera.position.x = Math.sin(time) * 5;
      camera.position.z = Math.cos(time) * 5;
      camera.lookAt(scene.position);
      
      renderer.render(scene, camera);
    };
    
    // Handle window resize
    const handleResize = () => {
      if (!containerRef.current) return;
      
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;
      
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };
    
    window.addEventListener('resize', handleResize);
    
    // Start animation
    animate();
    
    // Signal that the scene has loaded
    setTimeout(() => setIsLoaded(true), 300);
    
    // Cleanup
    return () => {
      cancelAnimationFrame(animationFrameId.current);
      window.removeEventListener('resize', handleResize);
      if (containerRef.current && containerRef.current.contains(renderer.domElement)) {
        containerRef.current.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div 
      ref={containerRef} 
      className="absolute inset-0"
      style={{ 
        position: 'absolute',
        opacity: isLoaded ? 1 : 0,
        transition: 'opacity 1s ease-in-out'
      }}
    />
  );
};

export default ThreeJsHero;
