
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

// Define health data types
interface HealthData {
  steps: number;
  calories: number;
  heartRate: number;
  workoutMinutes: number;
}

interface HealthState {
  data: HealthData;
  isConnected: boolean;
  loading: boolean;
  error: string | null;
  connectedService: string | null;
}

const initialState: HealthState = {
  data: {
    steps: 0,
    calories: 0,
    heartRate: 0,
    workoutMinutes: 0,
  },
  isConnected: false,
  loading: false,
  error: null,
  connectedService: null
};

// Create async thunk for connecting to fitness tracking service
export const connectFitnessService = createAsyncThunk(
  'health/connect',
  async (serviceId: string, { rejectWithValue }) => {
    try {
      // This would be replaced with an actual API call to the selected fitness service
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mock successful connection with sample data based on the service
      // In production, this would call the appropriate API for Google Fit, Apple Health, etc.
      let baseSteps = 8000 + Math.floor(Math.random() * 2000);
      let baseCalories = 400 + Math.floor(Math.random() * 150);
      let baseHeartRate = 65 + Math.floor(Math.random() * 15);
      let baseWorkoutMinutes = 40 + Math.floor(Math.random() * 20);
      
      // Slight variations based on the service
      if (serviceId === 'googlefit' || serviceId === 'fitbit') {
        baseSteps += 500;
        baseWorkoutMinutes += 5;
      } else if (serviceId === 'applehealth' || serviceId === 'garmin') {
        baseCalories += 50;
        baseHeartRate -= 3;
      } else if (serviceId === 'strava') {
        baseWorkoutMinutes += 15;
        baseCalories += 100;
      }
      
      return {
        serviceId,
        data: {
          steps: baseSteps,
          calories: baseCalories,
          heartRate: baseHeartRate,
          workoutMinutes: baseWorkoutMinutes,
        }
      };
    } catch (error) {
      return rejectWithValue('Failed to connect to fitness service');
    }
  }
);

// Create async thunk for fetching health data
export const fetchHealthData = createAsyncThunk(
  'health/fetchData',
  async (_, { getState, rejectWithValue }) => {
    const { health } = getState() as { health: HealthState };
    
    // Check if already connected
    if (!health.isConnected) {
      return rejectWithValue('Not connected to fitness service');
    }
    
    try {
      // This would be replaced with an actual API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const serviceId = health.connectedService || 'default';
      let stepVariance = Math.floor(Math.random() * 2000);
      let calorieVariance = Math.floor(Math.random() * 100);
      let heartRateVariance = Math.floor(Math.random() * 10);
      let workoutVariance = Math.floor(Math.random() * 15);
      
      // Return updated health data with some trends based on previous values
      // In a real app, this would fetch actual data from the connected service's API
      const currentSteps = health.data.steps;
      return {
        steps: Math.max(currentSteps - 500, 0) + stepVariance,
        calories: Math.max(health.data.calories - 50, 0) + calorieVariance,
        heartRate: Math.max(65, Math.min(100, health.data.heartRate - 3 + heartRateVariance)),
        workoutMinutes: Math.max(health.data.workoutMinutes - 5, 0) + workoutVariance,
      };
    } catch (error) {
      return rejectWithValue('Failed to fetch health data');
    }
  }
);

const healthSlice = createSlice({
  name: 'health',
  initialState,
  reducers: {
    disconnectFitnessService: (state) => {
      state.isConnected = false;
      state.connectedService = null;
      state.data = initialState.data;
    },
    toggleUnitSystem: (state, action) => {
      // This would store the user's preference for unit display (metric vs imperial)
      // The actual conversion is handled in the component
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(connectFitnessService.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(connectFitnessService.fulfilled, (state, action) => {
        state.loading = false;
        state.isConnected = true;
        state.connectedService = action.payload.serviceId;
        state.data = action.payload.data;
      })
      .addCase(connectFitnessService.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(fetchHealthData.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchHealthData.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload;
      })
      .addCase(fetchHealthData.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { disconnectFitnessService, toggleUnitSystem } = healthSlice.actions;
export default healthSlice.reducer;
