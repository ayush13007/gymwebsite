
import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Gym } from '@/types/gym'; 

interface GymState {
  gyms: Gym[];
  selectedGym: Gym | null;
  loading: boolean;
  error: string | null;
}

const initialState: GymState = {
  gyms: [
    {
      id: 'gym-1',
      name: 'Elite Fitness',
      location: '123 Main Street, New York',
      description: 'Premium fitness center with state-of-the-art equipment',
      rating: 4.8,
      reviewCount: 245,
      equipment: ['Treadmills', 'Free Weights', 'CrossFit Rig'],
      services: ['Personal Training', 'Group Classes', 'Nutrition Advice'],
      openingHours: '6:00 AM - 10:00 PM',
      price: 75,
      currency: 'USD'
    },
    {
      id: 'gym-2',
      name: 'Power House',
      location: '456 Broad Avenue, Los Angeles',
      description: 'Hardcore training center for serious athletes',
      rating: 4.6,
      reviewCount: 189,
      equipment: ['Olympic Weights', 'Combat Area', 'Powerlifting Zone'],
      services: ['Strength Training', 'MMA Classes', 'Recovery Center'],
      openingHours: '5:00 AM - 11:00 PM',
      price: 85,
      currency: 'USD'
    },
    {
      id: 'gym-3',
      name: 'Zen Fitness',
      location: '789 Calm Street, Seattle',
      description: 'Holistic approach to fitness and wellness',
      rating: 4.9,
      reviewCount: 312,
      equipment: ['Yoga Studio', 'Meditation Room', 'Light Weights'],
      services: ['Yoga Classes', 'Meditation', 'Wellness Coaching'],
      openingHours: '7:00 AM - 9:00 PM',
      price: 65,
      currency: 'USD'
    }
  ],
  selectedGym: null,
  loading: false,
  error: null
};

const gymSlice = createSlice({
  name: 'gyms',
  initialState,
  reducers: {
    selectGym: (state, action: PayloadAction<string>) => {
      state.selectedGym = state.gyms.find(gym => gym.id === action.payload) || null;
    },
    setGyms: (state, action: PayloadAction<Gym[]>) => {
      state.gyms = action.payload;
    },
    addGym: (state, action: PayloadAction<Gym>) => {
      state.gyms.push(action.payload);
    },
    updateGym: (state, action: PayloadAction<Gym>) => {
      const index = state.gyms.findIndex(gym => gym.id === action.payload.id);
      if (index !== -1) {
        state.gyms[index] = action.payload;
        if (state.selectedGym && state.selectedGym.id === action.payload.id) {
          state.selectedGym = action.payload;
        }
      }
    },
    deleteGym: (state, action: PayloadAction<string>) => {
      state.gyms = state.gyms.filter(gym => gym.id !== action.payload);
      if (state.selectedGym && state.selectedGym.id === action.payload) {
        state.selectedGym = null;
      }
    },
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
    setError: (state, action: PayloadAction<string | null>) => {
      state.error = action.payload;
    }
  }
});

export const { 
  selectGym, 
  setGyms, 
  addGym, 
  updateGym, 
  deleteGym, 
  setLoading, 
  setError 
} = gymSlice.actions;

export default gymSlice.reducer;
