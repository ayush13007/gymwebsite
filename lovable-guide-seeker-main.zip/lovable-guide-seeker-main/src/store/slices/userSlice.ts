import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Message } from '@/hooks/useChatbot';

export interface UserState {
  isAuthenticated: boolean;
  username: string;
  email: string;
  phone: string;
  address: string;
  bookings: any[];
  memberships: any[];
  chatHistory: Message[];
}

const initialState: UserState = {
  isAuthenticated: false,
  username: '',
  email: '',
  phone: '',
  address: '',
  bookings: [],
  memberships: [],
  chatHistory: []
};

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    login: (state, action: PayloadAction<Partial<UserState>>) => {
      state.isAuthenticated = true;
      if (action.payload.username) state.username = action.payload.username;
      if (action.payload.email) state.email = action.payload.email;
      if (action.payload.phone) state.phone = action.payload.phone;
      if (action.payload.address) state.address = action.payload.address;
    },
    logout: (state) => {
      return initialState;
    },
    updateProfile: (state, action: PayloadAction<Partial<UserState>>) => {
      return { ...state, ...action.payload };
    },
    addBooking: (state, action: PayloadAction<any>) => {
      state.bookings.push(action.payload);
    },
    addMembership: (state, action: PayloadAction<any>) => {
      state.memberships.push(action.payload);
    },
    addChatHistory: (state, action: PayloadAction<Message>) => {
      // Keep only the last 100 messages to prevent state from growing too large
      if (state.chatHistory.length >= 100) {
        state.chatHistory = [...state.chatHistory.slice(1), action.payload];
      } else {
        state.chatHistory.push(action.payload);
      }
    },
    clearChatHistory: (state) => {
      state.chatHistory = [];
    }
  }
});

export const { 
  login, 
  logout, 
  updateProfile, 
  addBooking, 
  addMembership,
  addChatHistory,
  clearChatHistory
} = userSlice.actions;

export default userSlice.reducer;
