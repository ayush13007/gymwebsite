
import { configureStore } from '@reduxjs/toolkit';
import userReducer from './slices/userSlice';
import gymReducer from './slices/gymSlice';
import healthReducer from './slices/healthSlice';

export const store = configureStore({
  reducer: {
    user: userReducer,
    gyms: gymReducer,
    health: healthReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
