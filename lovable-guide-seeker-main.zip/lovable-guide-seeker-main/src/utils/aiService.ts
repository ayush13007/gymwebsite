
import { Message } from '@/hooks/useChatbot';

// You would replace this with your actual API key handling
const getApiKey = () => {
  // In production, this should come from secure storage, not localStorage
  return localStorage.getItem('openai_api_key') || '';
};

// Default system prompt that guides the AI assistant's behavior
const DEFAULT_SYSTEM_PROMPT = `
You are GymZone AI, a helpful fitness assistant for the GymZone platform.
Your personality is motivating, knowledgeable, and supportive.

You can help users with:
- Workout recommendations
- Gym equipment information
- Booking appointments
- Fitness tracking advice
- Nutrition guidance
- Account management

When responding, be concise but informative.
Always encourage users to maintain their fitness journey.
`;

interface ContextData {
  username: string;
  isAuthenticated: boolean;
  recentWorkouts: any | null;
  bookings: any[];
  memberships: any[];
}

// Function to process messages through OpenAI API
export const sendMessageToAI = async (
  userMessage: string,
  chatHistory: Message[],
  contextData: ContextData
): Promise<string> => {
  // Check if OpenAI API key is available
  const apiKey = getApiKey();
  
  if (!apiKey) {
    // Use a fallback system if no API key is available
    return useFallbackResponse(userMessage, contextData);
  }
  
  try {
    // Format message history for OpenAI
    const messages = formatMessagesForAPI(chatHistory, userMessage, contextData);
    
    // Make the API call to OpenAI
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini', // You can change the model as needed
        messages: messages,
        temperature: 0.7,
        max_tokens: 500,
      })
    });
    
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    
    const data = await response.json();
    return data.choices[0].message.content.trim();
    
  } catch (error) {
    console.error('Error calling OpenAI API:', error);
    
    // Fall back to rule-based responses
    return useFallbackResponse(userMessage, contextData);
  }
};

// Format messages for the OpenAI API
const formatMessagesForAPI = (
  chatHistory: Message[],
  currentMessage: string,
  contextData: ContextData
) => {
  // Start with system message
  const messages = [
    { 
      role: 'system', 
      content: enhanceSystemPrompt(DEFAULT_SYSTEM_PROMPT, contextData) 
    }
  ];
  
  // Add relevant chat history (last 10 messages maximum)
  const relevantHistory = chatHistory.slice(-10);
  relevantHistory.forEach(msg => {
    messages.push({
      role: msg.role,
      content: msg.content
    });
  });
  
  // Add current user message
  messages.push({
    role: 'user',
    content: currentMessage
  });
  
  return messages;
};

// Enhance system prompt with user context
const enhanceSystemPrompt = (basePrompt: string, contextData: ContextData) => {
  let enhancedPrompt = basePrompt;
  
  if (contextData.isAuthenticated) {
    enhancedPrompt += `\nYou're speaking with ${contextData.username}, a registered user.`;
    
    if (contextData.bookings && contextData.bookings.length > 0) {
      enhancedPrompt += `\nThey have ${contextData.bookings.length} upcoming gym sessions booked.`;
    }
    
    if (contextData.memberships && contextData.memberships.length > 0) {
      enhancedPrompt += `\nThey have active memberships.`;
    }
  } else {
    enhancedPrompt += `\nYou're speaking with a guest user. Encourage them to sign up for a GymZone account.`;
  }
  
  return enhancedPrompt;
};

// Fallback response system for when API is unavailable
const useFallbackResponse = (userMessage: string, contextData: ContextData): string => {
  const message = userMessage.toLowerCase();
  
  // Simple keyword-based response system
  if (message.includes('hello') || message.includes('hi ') || message.includes('hey')) {
    return `Hello${contextData.isAuthenticated ? ' ' + contextData.username : ''}! How can I assist with your fitness journey today?`;
  }
  
  if (message.includes('workout') || message.includes('exercise')) {
    return "I recommend starting with a mix of cardio and strength training. Would you like workout suggestions for a specific fitness level or goal?";
  }
  
  if (message.includes('book') || message.includes('appointment') || message.includes('session')) {
    return "You can book gym sessions through our easy booking system. Would you like me to help you navigate to the booking page?";
  }
  
  if (message.includes('membership') || message.includes('price') || message.includes('cost')) {
    return "GymZone offers several membership options starting from $29.99/month. Our premium plan includes access to all facilities and personal training sessions. Would you like more details?";
  }
  
  if (message.includes('location') || message.includes('near me') || message.includes('where')) {
    return "GymZone has over 500 locations worldwide. You can use our 'Find Gyms' feature to locate the nearest gym to you with all the amenities you need.";
  }
  
  // Default response
  return "I'm here to help with your fitness journey! You can ask me about workouts, gym facilities, booking sessions, or membership options.";
};
