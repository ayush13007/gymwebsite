
import barba from '@barba/core';
import { gsap } from 'gsap';

export const setupBarba = () => {
  // Check if Barba is already initialized
  if (barba.initiated) {
    console.info('[@barba/core] Barba is already initialized');
    return;
  }

  // Check if the Barba wrapper element exists
  const barbaWrapper = document.querySelector('[data-barba="wrapper"]');
  
  if (!barbaWrapper) {
    console.warn('[@barba/core] No Barba wrapper found. Page transitions will not be applied.');
    return; // Exit early if no wrapper is found
  }
  
  // Add CSS for transition elements
  const style = document.createElement('style');
  style.textContent = `
    .page-transition {
      position: relative;
      overflow: hidden;
    }
    .transition-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: #111827;
      z-index: 999;
      transform: scaleY(0);
      transform-origin: bottom;
      pointer-events: none;
    }
  `;
  document.head.appendChild(style);
  
  try {
    barba.init({
      preventRunning: true,
      transitions: [
        {
          name: 'premium-transition',
          async leave(data) {
            // Create overlay for transition
            const overlay = document.createElement('div');
            overlay.className = 'transition-overlay';
            document.body.appendChild(overlay);
            
            // Animate page exit
            await gsap.timeline()
              .to(data.current.container, {
                opacity: 0,
                y: -30,
                duration: 0.4,
                ease: "power2.in"
              })
              .to(overlay, {
                scaleY: 1,
                transformOrigin: "bottom",
                duration: 0.5,
                ease: "power2.inOut"
              });
          },
          async enter(data) {
            // Get overlay
            const overlay = document.querySelector('.transition-overlay');
            
            // Setup initial state of new page
            gsap.set(data.next.container, {
              opacity: 0,
              y: 30
            });
            
            // Animate page entry
            await gsap.timeline()
              .to(overlay, {
                scaleY: 0,
                transformOrigin: "top",
                duration: 0.5,
                ease: "power2.inOut"
              })
              .to(data.next.container, {
                opacity: 1,
                y: 0,
                duration: 0.4,
                ease: "power2.out"
              });
            
            // Remove overlay after transition
            if (overlay && overlay.parentNode) {
              overlay.parentNode.removeChild(overlay);
            }
            
            // Trigger scroll animations
            setupScrollAnimations();

            // Scroll to top on page change
            window.scrollTo(0, 0);
          }
        }
      ]
    });
  } catch (error) {
    console.error('Error initializing Barba.js:', error);
    
    // Fallback - ensure pages are at least visible if Barba fails
    const containers = document.querySelectorAll('[data-barba="container"]');
    containers.forEach(container => {
      if (container instanceof HTMLElement) {
        container.style.opacity = '1';
      }
    });
  }
};

// Setup animations for elements when they come into view
const setupScrollAnimations = () => {
  const animateOnScroll = (entries: IntersectionObserverEntry[]) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate-in');
      }
    });
  };

  // Create observer
  const observer = new IntersectionObserver(animateOnScroll, {
    root: null,
    threshold: 0.1,
    rootMargin: '0px'
  });

  // Observe elements with animate-on-scroll class
  const elements = document.querySelectorAll('.animate-on-scroll');
  elements.forEach(el => observer.observe(el));
};
