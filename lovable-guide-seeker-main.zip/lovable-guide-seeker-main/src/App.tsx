
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Provider } from 'react-redux';
import { store } from './store';
import Layout from "./components/Layout";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import NotFound from "./pages/NotFound";
import Gyms from "./pages/Gyms";
import Dashboard from "./pages/Dashboard";
import PremiumGyms from "./pages/features/PremiumGyms";
import ExploreIn3D from "./pages/features/ExploreIn3D";
import EasyBooking from "./pages/features/EasyBooking";
import FitnessTrackingPage from "./pages/features/FitnessTrackingPage";
import FitnessHub from "./pages/features/FitnessHub";
import CommunityPage from "./pages/features/CommunityPage";
import SecurePayments from "./pages/features/SecurePayments";
import Blog from "./pages/Blog";
import Community from "./pages/Community";
import FitnessFeatures from "./pages/FitnessFeatures";

const queryClient = new QueryClient();

const App = () => (
  <Provider store={store}>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route index element={<Home />} />
              <Route path="login" element={<Login />} />
              <Route path="register" element={<Register />} />
              <Route path="gyms" element={<Gyms />} />
              <Route path="dashboard" element={<Dashboard />} />
              <Route path="fitness-features" element={<FitnessFeatures />} />
              <Route path="features/premium-gyms" element={<PremiumGyms />} />
              <Route path="features/explore-3d" element={<ExploreIn3D />} />
              <Route path="features/easy-booking" element={<EasyBooking />} />
              <Route path="features/fitness-tracking" element={<FitnessTrackingPage />} />
              <Route path="features/fitness-hub" element={<FitnessHub />} />
              <Route path="features/community" element={<CommunityPage />} />
              <Route path="features/secure-payments" element={<SecurePayments />} />
              <Route path="blog" element={<Blog />} />
              <Route path="community" element={<Community />} />
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </Provider>
);

export default App;
