
import { toast as sonnerToast } from "sonner";

type ToastProps = {
  title?: string;
  description?: string;
  variant?: "default" | "destructive" | undefined;
  action?: React.ReactNode;
  duration?: number;
};

export const toast = ({ title, description, variant = "default", action, duration = 5000 }: ToastProps) => {
  const options = {
    duration,
    action,
    className: variant === "destructive" ? "destructive" : ""
  };

  if (title && description) {
    return sonnerToast(title, {
      description,
      ...options
    });
  }
  
  return sonnerToast(description || title || "", options);
};

// Mock toasts array for compatibility
const toasts: any[] = [];

export const useToast = () => {
  return { toast, toasts };
};
