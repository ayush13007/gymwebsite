import { useEffect, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { useAppDispatch, useAppSelector } from './redux';
import { addChatHistory } from '@/store/slices/userSlice';
import { sendMessageToAI } from '@/utils/aiService';

export interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

export const useChatbot = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const dispatch = useAppDispatch();
  const user = useAppSelector((state) => state.user);

  // Load previous chat history from localStorage
  useEffect(() => {
    const savedMessages = localStorage.getItem('chatHistory');
    if (savedMessages) {
      try {
        setMessages(JSON.parse(savedMessages));
      } catch (e) {
        console.error('Failed to parse chat history:', e);
        localStorage.removeItem('chatHistory');
      }
    } else {
      // Add welcome message for first-time users
      const welcomeMessage = {
        id: uuidv4(),
        content: "Welcome to GymZone AI Assistant! How can I help you today with your fitness journey?",
        role: 'assistant' as const,
        timestamp: new Date(),
      };
      setMessages([welcomeMessage]);
    }
  }, []);

  // Save messages to localStorage whenever they change
  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem('chatHistory', JSON.stringify(messages.slice(-50))); // Keep last 50 messages
    }
  }, [messages]);

  const sendMessage = async (content: string) => {
    if (!content.trim()) return;
    
    // Create user message
    const userMessage: Message = {
      id: uuidv4(),
      content,
      role: 'user',
      timestamp: new Date(),
    };
    
    // Add user message to chat
    setMessages(prev => [...prev, userMessage]);
    
    // If user is authenticated, add to global chat history
    if (user.isAuthenticated) {
      dispatch(addChatHistory(userMessage));
    }

    // Process with AI
    try {
      setIsLoading(true);
      
      // Get context data for more personalized responses
      const contextData = {
        username: user.username || 'User',
        isAuthenticated: user.isAuthenticated,
        recentWorkouts: user.isAuthenticated ? 'recent workout data' : null,
        bookings: user.bookings || [],
        memberships: user.memberships || []
      };
      
      // Send to AI service
      const response = await sendMessageToAI(content, messages, contextData);
      
      // Create AI response message
      const aiMessage: Message = {
        id: uuidv4(),
        content: response,
        role: 'assistant',
        timestamp: new Date(),
      };
      
      // Add AI message to chat
      setMessages(prev => [...prev, aiMessage]);
      
      // If user is authenticated, add to global chat history
      if (user.isAuthenticated) {
        dispatch(addChatHistory(aiMessage));
      }
      
    } catch (error) {
      console.error('Error sending message to AI:', error);
      
      // Create error message
      const errorMessage: Message = {
        id: uuidv4(),
        content: "I'm having trouble connecting to my brain right now. Please try again in a moment.",
        role: 'assistant',
        timestamp: new Date(),
      };
      
      // Add error message to chat
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearMessages = () => {
    // Keep just the welcome message
    const welcomeMessage = {
      id: uuidv4(),
      content: "Welcome to GymZone AI Assistant! How can I help you today with your fitness journey?",
      role: 'assistant' as const,
      timestamp: new Date(),
    };
    setMessages([welcomeMessage]);
    localStorage.removeItem('chatHistory');
  };

  return {
    messages,
    isLoading,
    sendMessage,
    clearMessages,
  };
};
