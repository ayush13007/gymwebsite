
import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Format currency to display in a nice way
export function formatCurrency(amount: number, currency: string = "USD"): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
  }).format(amount);
}

// Format date in a consistent way throughout the app
export function formatDate(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

// Format time slots for gym bookings
export function formatTimeSlot(time: string): string {
  // Converts 24-hour format to 12-hour format with AM/PM
  const [hours, minutes] = time.split(':');
  const hour = parseInt(hours, 10);
  const suffix = hour >= 12 ? 'PM' : 'AM';
  const displayHour = hour % 12 || 12;
  return `${displayHour}:${minutes} ${suffix}`;
}

// Generate a range of time slots
export function generateTimeSlots(
  start: number = 6, // 6 AM
  end: number = 22, // 10 PM
  intervalMinutes: number = 60 // 1 hour intervals
): string[] {
  const slots = [];
  for (let hour = start; hour <= end; hour += intervalMinutes / 60) {
    const fullHour = Math.floor(hour);
    const minutes = (hour - fullHour) * 60;
    const formatted = `${fullHour.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    slots.push(formatted);
  }
  return slots;
}
