import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Activity, 
  Calendar, 
  Clock, 
  Heart, 
  BarChart3, 
  Settings, 
  User,
  Dumbbell
} from "lucide-react";
import { useAppSelector } from "@/hooks/redux";
import FitnessTracking from "@/components/FitnessTracking";
import ThreeDGymView from "@/components/ThreeDGymView";

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState("overview");
  const user = useAppSelector(state => state.user);
  const health = useAppSelector(state => state.health);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100,
      },
    },
  };

  return (
    <div className="container py-8">
      <motion.h1 
        className="text-4xl font-bold mb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Dashboard
      </motion.h1>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-muted">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <Activity size={16} />
            <span>Overview</span>
          </TabsTrigger>
          <TabsTrigger value="bookings" className="flex items-center gap-2">
            <Calendar size={16} />
            <span>Bookings</span>
          </TabsTrigger>
          <TabsTrigger value="gymview" className="flex items-center gap-2">
            <Dumbbell size={16} />
            <span>3D Gym</span>
          </TabsTrigger>
          <TabsTrigger value="profile" className="flex items-center gap-2">
            <User size={16} />
            <span>Profile</span>
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center gap-2">
            <Settings size={16} />
            <span>Settings</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <motion.div 
            className="grid gap-4 md:grid-cols-2 lg:grid-cols-3"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            <motion.div variants={itemVariants}>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Total Workouts
                  </CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">24</div>
                  <p className="text-xs text-muted-foreground">
                    +2 from last month
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={itemVariants}>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Active Memberships
                  </CardTitle>
                  <BarChart3 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">2</div>
                  <p className="text-xs text-muted-foreground">
                    Elite Training Center, Power Gym
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={itemVariants}>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Health Stats
                  </CardTitle>
                  <Heart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{health.data.steps.toLocaleString()}</div>
                  <p className="text-xs text-muted-foreground">
                    Steps today
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={itemVariants} className="md:col-span-2 lg:col-span-3">
              <Card>
                <CardHeader>
                  <CardTitle>Fitness Tracking</CardTitle>
                  <CardDescription>
                    Connect with Google Fit to track your fitness progress
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <FitnessTracking />
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </TabsContent>

        <TabsContent value="bookings">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Bookings</CardTitle>
              <CardDescription>
                View and manage your scheduled gym sessions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p>You have no upcoming bookings.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="gymview">
          <Card>
            <CardHeader>
              <CardTitle>3D Gym Preview</CardTitle>
              <CardDescription>
                Explore the gym in 3D using WebGL
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ThreeDGymView />
              <p className="mt-4 text-center text-sm text-muted-foreground">
                Click and drag to rotate the view
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
              <CardDescription>
                View and update your profile details
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div>
                  <div className="font-medium">Username</div>
                  <div>{user.username || "Not set"}</div>
                </div>
                <div>
                  <div className="font-medium">Email</div>
                  <div>{user.email || "Not set"}</div>
                </div>
                <div>
                  <div className="font-medium">Phone</div>
                  <div>{user.phone || "Not set"}</div>
                </div>
                <div>
                  <div className="font-medium">Address</div>
                  <div>{user.address || "Not set"}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Settings</CardTitle>
              <CardDescription>
                Manage your account settings and preferences
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p>Settings options will be available soon.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Dashboard;
