
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Activity, Heart, BarChart2, Award, Target, Smartphone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import FitnessTracking from "@/components/FitnessTracking";

// Mock data for demo charts
const fitnessData = {
  weeklyProgress: [
    { day: "Mon", calories: 320, target: 400 },
    { day: "Tue", calories: 480, target: 400 },
    { day: "Wed", calories: 390, target: 400 },
    { day: "Thu", calories: 430, target: 400 },
    { day: "Fri", calories: 500, target: 400 },
    { day: "Sat", calories: 350, target: 400 },
    { day: "Sun", calories: 200, target: 400 }
  ],
  monthlyWorkouts: 18,
  streak: 5,
  caloriesBurned: 3240
};

const FitnessTrackingPage = () => {
  return (
    <div className="container max-w-7xl py-12 px-4 sm:px-6 lg:py-16 lg:px-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
        <Link to="/" className="hover:text-primary transition-colors">Home</Link>
        <span>/</span>
        <span>Fitness Tracking</span>
      </div>

      {/* Hero section */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center mb-16"
      >
        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          Track Your Fitness Journey
        </h1>
        <p className="max-w-2xl mx-auto text-xl text-muted-foreground">
          Connect your fitness devices and apps to track your progress and achieve your goals faster.
        </p>
      </motion.div>

      {/* Interactive Fitness Stats Component */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.6 }}
        className="mb-16"
      >
        <FitnessTracking />
      </motion.div>

      {/* Tracking Features */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold mb-10 text-center">Comprehensive Tracking Features</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              icon: <Heart className="h-6 w-6" />,
              title: "Heart Rate Monitoring",
              description: "Track your heart rate during workouts and throughout the day to optimize training intensity."
            },
            {
              icon: <Activity className="h-6 w-6" />,
              title: "Workout Analysis",
              description: "Get detailed insights on your performance with comprehensive workout metrics."
            },
            {
              icon: <BarChart2 className="h-6 w-6" />,
              title: "Progress Visualization",
              description: "See your fitness journey with easy-to-understand charts and graphs."
            },
            {
              icon: <Award className="h-6 w-6" />,
              title: "Achievements & Badges",
              description: "Earn rewards for hitting milestones and staying consistent with your fitness routine."
            },
            {
              icon: <Target className="h-6 w-6" />,
              title: "Custom Goals",
              description: "Set personalized targets based on your fitness level and aspirations."
            },
            {
              icon: <Smartphone className="h-6 w-6" />,
              title: "Device Integration",
              description: "Connect with popular fitness trackers, smartwatches, and health apps."
            }
          ].map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + i * 0.1, duration: 0.6 }}
              className="bg-white/5 backdrop-blur-sm rounded-xl p-6"
            >
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Demo Dashboard */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold mb-10 text-center">Your Fitness Dashboard</h2>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="bg-white/5 backdrop-blur-sm rounded-xl p-6"
        >
          <Tabs defaultValue="overview">
            <TabsList className="grid w-full grid-cols-4 mb-8">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="workouts">Workouts</TabsTrigger>
              <TabsTrigger value="nutrition">Nutrition</TabsTrigger>
              <TabsTrigger value="goals">Goals</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-background/80 p-6 rounded-lg flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Monthly Workouts</p>
                    <h3 className="text-3xl font-bold">{fitnessData.monthlyWorkouts}</h3>
                  </div>
                  <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center">
                    <Activity className="h-8 w-8 text-primary" />
                  </div>
                </div>
                
                <div className="bg-background/80 p-6 rounded-lg flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Current Streak</p>
                    <h3 className="text-3xl font-bold">{fitnessData.streak} days</h3>
                  </div>
                  <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center">
                    <Award className="h-8 w-8 text-primary" />
                  </div>
                </div>
                
                <div className="bg-background/80 p-6 rounded-lg flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Calories Burned</p>
                    <h3 className="text-3xl font-bold">{fitnessData.caloriesBurned}</h3>
                  </div>
                  <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center">
                    <BarChart2 className="h-8 w-8 text-primary" />
                  </div>
                </div>
              </div>
              
              <div className="bg-background/80 p-6 rounded-lg">
                <h3 className="text-xl font-semibold mb-4">Weekly Progress</h3>
                <div className="h-64">
                  {/* This would be a real chart in a production app */}
                  <div className="h-full flex items-end justify-between">
                    {fitnessData.weeklyProgress.map((day, i) => (
                      <div key={i} className="flex flex-col items-center w-full">
                        <div className="relative w-full flex justify-center">
                          <div 
                            className="w-4/5 bg-primary/20 rounded-t-sm"
                            style={{ height: `${(day.target / 500) * 100}%` }}
                          ></div>
                          <div 
                            className="absolute bottom-0 w-3/5 bg-primary rounded-t-sm"
                            style={{ height: `${(day.calories / 500) * 100}%` }}
                          ></div>
                        </div>
                        <span className="mt-2 text-xs text-muted-foreground">{day.day}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="workouts" className="h-64 flex items-center justify-center text-muted-foreground">
              Workout history will appear here when you connect your fitness tracker.
            </TabsContent>
            
            <TabsContent value="nutrition" className="h-64 flex items-center justify-center text-muted-foreground">
              Nutrition tracking will appear here when you log your first meal.
            </TabsContent>
            
            <TabsContent value="goals" className="h-64 flex items-center justify-center text-muted-foreground">
              Set your fitness goals to see your progress tracking here.
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>

      {/* Integration Partners */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6, duration: 0.6 }}
        className="mb-16"
      >
        <h2 className="text-3xl font-bold mb-6 text-center">Compatible With Your Favorite Devices</h2>
        <p className="text-center text-muted-foreground mb-8 max-w-3xl mx-auto">
          Our fitness tracking system integrates seamlessly with popular fitness wearables and apps, 
          so you can keep using the devices you love.
        </p>
        
        <div className="flex flex-wrap justify-center gap-8 items-center">
          {["Fitbit", "Apple Health", "Garmin", "Samsung Health", "Google Fit", "Strava"].map((partner, i) => (
            <div key={i} className="py-4 px-8 bg-white/5 backdrop-blur-sm rounded-lg">
              <span className="text-xl font-medium">{partner}</span>
            </div>
          ))}
        </div>
      </motion.div>

      {/* CTA */}
      <div className="bg-gradient-to-r from-primary to-purple-600 rounded-3xl p-8 md:p-12 text-white">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to track your progress?</h2>
          <p className="text-lg mb-8 text-white/90">
            Sign up today and connect your fitness devices to start your journey to a healthier you.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90">
                Start Tracking Now
              </Button>
            </Link>
            <Link to="/gyms">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20">
                Find a Gym First
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="mt-12 flex justify-center">
        <Link to="/" className="flex items-center text-primary hover:text-primary/80 transition-colors">
          <ArrowLeft className="h-4 w-4 mr-2" />
          <span>Back to Home</span>
        </Link>
      </div>
    </div>
  );
};

export default FitnessTrackingPage;
