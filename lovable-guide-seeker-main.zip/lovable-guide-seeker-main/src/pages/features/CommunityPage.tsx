
import { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, MessageSquare, Heart, Users, Share2, User, ThumbsUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

// Mock community data
const communityPosts = [
  {
    id: 1,
    user: {
      name: "Alex Johnson",
      avatar: "https://randomuser.me/api/portraits/men/32.jpg",
      handle: "@alexfit"
    },
    content: "Just completed my first 5K run! Thanks to everyone in the GymZone community for the motivation and support. 💪",
    image: "/lovable-uploads/51f05c81-c8ec-4b84-9af1-685dd918ee86.png",
    timestamp: "2 hours ago",
    likes: 24,
    comments: 5
  },
  {
    id: 2,
    user: {
      name: "Sarah Williams",
      avatar: "https://randomuser.me/api/portraits/women/44.jpg",
      handle: "@sarahw"
    },
    content: "New personal record on deadlifts today! 225lbs x 5 reps. Hard work is paying off. What's your PR?",
    image: null,
    timestamp: "5 hours ago",
    likes: 42,
    comments: 12
  },
  {
    id: 3,
    user: {
      name: "Mike Chen",
      avatar: "https://randomuser.me/api/portraits/men/62.jpg",
      handle: "@mikefit"
    },
    content: "Morning workout with the GymZone crew! Love the energy in our community classes. Who's joining tomorrow?",
    image: null,
    timestamp: "Yesterday",
    likes: 31,
    comments: 8
  }
];

const challenges = [
  {
    id: 1,
    title: "30-Day Core Challenge",
    participants: 1243,
    progress: 70,
    days: "18 days left"
  },
  {
    id: 2,
    title: "10K Steps Challenge",
    participants: 2587,
    progress: 45,
    days: "15 days left"
  },
  {
    id: 3,
    title: "Summer Shred Challenge",
    participants: 987,
    progress: 90,
    days: "3 days left"
  }
];

const groups = [
  {
    id: 1,
    name: "Runners Club",
    members: 532,
    description: "For all running enthusiasts, from beginners to marathoners."
  },
  {
    id: 2,
    name: "Strength Training",
    members: 1243,
    description: "Discuss techniques, routines, and progress for all strength training exercises."
  },
  {
    id: 3,
    name: "Yoga & Flexibility",
    members: 875,
    description: "Share your journey to better flexibility and mindfulness through yoga."
  }
];

const CommunityPage = () => {
  const [activeTab, setActiveTab] = useState("feed");
  const [likedPosts, setLikedPosts] = useState<number[]>([]);

  const handleLikePost = (postId: number) => {
    if (likedPosts.includes(postId)) {
      setLikedPosts(likedPosts.filter(id => id !== postId));
    } else {
      setLikedPosts([...likedPosts, postId]);
    }
  };

  return (
    <div className="container max-w-7xl py-12 px-4 sm:px-6 lg:py-16 lg:px-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
        <Link to="/" className="hover:text-primary transition-colors">Home</Link>
        <span>/</span>
        <span>Community</span>
      </div>

      {/* Hero section */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center mb-16"
      >
        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          Join Our Fitness Community
        </h1>
        <p className="max-w-2xl mx-auto text-xl text-muted-foreground">
          Connect with like-minded fitness enthusiasts, share your journey, and stay motivated with group challenges.
        </p>
      </motion.div>

      {/* Community Tabs */}
      <div className="mb-16">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mb-8">
            <TabsTrigger value="feed">Community Feed</TabsTrigger>
            <TabsTrigger value="challenges">Challenges</TabsTrigger>
            <TabsTrigger value="groups">Groups</TabsTrigger>
          </TabsList>
          
          <TabsContent value="feed" className="space-y-6">
            {/* New post form */}
            <Card className="border-none bg-white/5 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <div className="flex space-x-4">
                  <Avatar>
                    <AvatarImage src="https://github.com/shadcn.png" />
                    <AvatarFallback>YN</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <textarea
                      className="w-full bg-transparent border border-border rounded-lg p-3 resize-none focus:outline-none focus:ring-1 focus:ring-primary"
                      placeholder="Share your fitness update with the community..."
                      rows={2}
                    />
                    <div className="flex justify-between mt-3">
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">Add Photo</Button>
                        <Button variant="outline" size="sm">Tag Gym</Button>
                      </div>
                      <Button size="sm">Post Update</Button>
                    </div>
                  </div>
                </div>
              </CardHeader>
            </Card>
            
            {/* Posts feed */}
            <div className="space-y-6">
              {communityPosts.map((post) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <Card className="border-none bg-white/5 backdrop-blur-sm overflow-hidden">
                    <CardHeader className="pb-3">
                      <div className="flex items-center space-x-4">
                        <Avatar>
                          <AvatarImage src={post.user.avatar} />
                          <AvatarFallback>{post.user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-semibold">{post.user.name}</div>
                          <div className="text-sm text-muted-foreground">{post.user.handle} • {post.timestamp}</div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pb-3">
                      <p className="mb-4">{post.content}</p>
                      {post.image && (
                        <div className="rounded-lg overflow-hidden mb-4">
                          <img 
                            src={post.image} 
                            alt="Post content" 
                            className="w-full object-cover h-64"
                          />
                        </div>
                      )}
                    </CardContent>
                    <CardFooter className="pt-0">
                      <div className="flex items-center space-x-4 w-full">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className={likedPosts.includes(post.id) ? "text-red-500" : ""}
                          onClick={() => handleLikePost(post.id)}
                        >
                          <Heart className={`h-4 w-4 mr-1 ${likedPosts.includes(post.id) ? "fill-current" : ""}`} />
                          <span>{likedPosts.includes(post.id) ? post.likes + 1 : post.likes}</span>
                        </Button>
                        <Button variant="ghost" size="sm">
                          <MessageSquare className="h-4 w-4 mr-1" />
                          <span>{post.comments}</span>
                        </Button>
                        <Button variant="ghost" size="sm" className="ml-auto">
                          <Share2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="challenges" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {challenges.map((challenge) => (
                <motion.div
                  key={challenge.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <Card className="border-none bg-white/5 backdrop-blur-sm overflow-hidden h-full">
                    <div className="h-2 bg-primary" style={{ width: `${challenge.progress}%` }}></div>
                    <CardHeader>
                      <h3 className="text-xl font-semibold">{challenge.title}</h3>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center mb-4">
                        <Users className="h-5 w-5 mr-2 text-muted-foreground" />
                        <span className="text-muted-foreground">{challenge.participants} participants</span>
                      </div>
                      <div className="mb-6">
                        <div className="flex justify-between mb-1 text-sm">
                          <span>Progress</span>
                          <span>{challenge.progress}%</span>
                        </div>
                        <div className="w-full h-2 bg-muted rounded-full">
                          <div className="h-full bg-primary rounded-full" style={{ width: `${challenge.progress}%` }}></div>
                        </div>
                      </div>
                      <div className="text-sm text-muted-foreground">{challenge.days}</div>
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full">Join Challenge</Button>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))}
            </div>
            
            <div className="text-center mt-8">
              <Button variant="outline">Browse All Challenges</Button>
            </div>
          </TabsContent>
          
          <TabsContent value="groups" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {groups.map((group) => (
                <motion.div
                  key={group.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <Card className="border-none bg-white/5 backdrop-blur-sm overflow-hidden h-full">
                    <CardHeader>
                      <h3 className="text-xl font-semibold">{group.name}</h3>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <User className="h-4 w-4 mr-1" />
                        <span>{group.members} members</span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="mb-6 text-muted-foreground">{group.description}</p>
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full">Join Group</Button>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))}
            </div>
            
            <div className="bg-white/5 backdrop-blur-sm p-6 rounded-lg mt-8">
              <h3 className="text-xl font-semibold mb-4">Create Your Own Group</h3>
              <p className="text-muted-foreground mb-6">
                Have a fitness interest not represented in our community? Start your own group and connect with like-minded members.
              </p>
              <Button>Create a Group</Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Community Benefits */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold mb-10 text-center">Benefits of Our Community</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            {
              icon: <Users className="h-6 w-6" />,
              title: "Support Network",
              description: "Connect with members who share your fitness goals and challenges."
            },
            {
              icon: <ThumbsUp className="h-6 w-6" />,
              title: "Stay Motivated",
              description: "Group challenges and community recognition help you stay on track."
            },
            {
              icon: <MessageSquare className="h-6 w-6" />,
              title: "Expert Advice",
              description: "Get tips from certified trainers and experienced fitness enthusiasts."
            }
          ].map((benefit, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + i * 0.1, duration: 0.6 }}
              className="bg-white/5 backdrop-blur-sm p-6 rounded-lg"
            >
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                {benefit.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
              <p className="text-muted-foreground">{benefit.description}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="bg-gradient-to-r from-primary to-purple-600 rounded-3xl p-8 md:p-12 text-white">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to join our fitness community?</h2>
          <p className="text-lg mb-8 text-white/90">
            Connect with thousands of fitness enthusiasts and get the support you need to achieve your goals.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90">
                Join the Community
              </Button>
            </Link>
            <Link to="/gyms">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20">
                Find Gym Partners
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="mt-12 flex justify-center">
        <Link to="/" className="flex items-center text-primary hover:text-primary/80 transition-colors">
          <ArrowLeft className="h-4 w-4 mr-2" />
          <span>Back to Home</span>
        </Link>
      </div>
    </div>
  );
};

export default CommunityPage;
