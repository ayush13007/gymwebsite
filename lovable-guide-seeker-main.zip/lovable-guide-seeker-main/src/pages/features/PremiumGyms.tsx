
import { ArrowLeft, ArrowRight, Dumbbell, Star } from "lucide-react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useEffect, useState } from "react";

// Mock gym data since the Redux store might not be fully set up
const mockGyms = [
  {
    id: '1',
    name: 'Elite Fitness Center',
    location: 'Downtown',
    description: 'State-of-the-art equipment with dedicated areas for various workout styles.',
    rating: 4.8,
    price: 99,
    facilities: ['Cardio Zone', 'Strength Training', 'Spa'],
    images: ["https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=1170&auto=format&fit=crop"]
  },
  {
    id: '2',
    name: 'PowerHouse Gym',
    location: 'Westside',
    description: 'Specializing in strength training with premium heavy-duty equipment.',
    rating: 4.7,
    price: 89,
    facilities: ['Olympic Lifting', 'Powerlifting Zone', 'Protein Bar'],
    images: ["https://images.unsplash.com/photo-1593079831268-3381b0db4a77?q=80&w=1169&auto=format&fit=crop"]
  },
  {
    id: '3',
    name: 'Zen Fitness Studio',
    location: 'Eastside',
    description: 'A balanced approach to fitness with both cardio and strength options.',
    rating: 4.9,
    price: 109,
    facilities: ['Yoga Studio', 'Meditation Room', 'Personal Training'],
    images: ["https://images.unsplash.com/photo-1571902943202-507ec2618e8f?q=80&w=1075&auto=format&fit=crop"]
  }
];

const PremiumGyms = () => {
  const [gyms, setGyms] = useState(mockGyms);
  
  return (
    <div className="container max-w-7xl py-12 px-4 sm:px-6 lg:py-16 lg:px-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
        <Link to="/" className="hover:text-primary transition-colors">Home</Link>
        <span>/</span>
        <span>Premium Gyms</span>
      </div>

      {/* Hero section */}
      <div className="relative overflow-hidden rounded-3xl mb-16">
        <div className="absolute inset-0">
          <img 
            src="/lovable-uploads/51f05c81-c8ec-4b84-9af1-685dd918ee86.png" 
            alt="Gym Training" 
            className="w-full h-full object-cover object-center" 
          />
          <div className="absolute inset-0 bg-black/60"></div>
        </div>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="relative px-8 py-32 sm:px-12 sm:py-40 lg:py-56 text-center"
        >
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-white mb-6">
            Premium Gyms
          </h1>
          <p className="max-w-2xl mx-auto text-xl text-white/80">
            Access to high-quality fitness centers with state-of-the-art equipment and expert trainers.
          </p>
        </motion.div>
      </div>

      {/* Features */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.6 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16"
      >
        {[
          {
            title: "State-of-the-art Equipment",
            description: "Access the latest fitness machines and premium weights at all of our partner gyms."
          },
          {
            title: "Expert Trainers",
            description: "Work with certified personal trainers who specialize in various fitness disciplines."
          },
          {
            title: "Luxury Amenities",
            description: "Enjoy premium locker rooms, saunas, pools, and recovery facilities."
          },
          {
            title: "Flexible Access",
            description: "Your membership gives you access to multiple premium locations across the city."
          },
          {
            title: "Clean Environment",
            description: "All our partner gyms maintain the highest standards of cleanliness."
          },
          {
            title: "Premium Classes",
            description: "Access exclusive group fitness classes led by top instructors."
          }
        ].map((feature, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 + i * 0.1, duration: 0.6 }}
          >
            <Card className="border-none bg-gradient-to-br from-white/5 to-white/10 shadow-lg h-full">
              <CardContent className="pt-6">
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <Dumbbell className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {/* Featured Gyms */}
      <div className="mb-16">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold">Featured Premium Gyms</h2>
          <Link to="/gyms" className="flex items-center text-primary hover:text-primary/80 transition-colors">
            <span className="mr-2">View All</span>
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {gyms.map((gym) => (
            <motion.div 
              key={gym.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="overflow-hidden rounded-lg shadow-lg"
            >
              <div className="h-56 overflow-hidden">
                <img 
                  src={gym.images[0]} 
                  alt={gym.name} 
                  className="w-full h-full object-cover object-center hover:scale-110 transition-transform duration-700"
                />
              </div>
              <div className="p-6 bg-white/5 backdrop-blur-lg">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xl font-bold">{gym.name}</h3>
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                    <span className="ml-1">{gym.rating}</span>
                  </div>
                </div>
                <p className="text-muted-foreground mb-4">{gym.location}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {gym.facilities.map((facility, i) => (
                    <span key={i} className="px-2 py-1 bg-primary/10 text-primary text-xs rounded">
                      {facility}
                    </span>
                  ))}
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-semibold">${gym.price}/month</span>
                  <Link to={`/gyms/${gym.id}`}>
                    <Button variant="outline" size="sm">View Details</Button>
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="bg-gradient-to-r from-primary to-purple-600 rounded-3xl p-8 md:p-12 text-white">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to experience premium fitness?</h2>
          <p className="text-lg mb-8 text-white/90">
            Join FitSpace today and get access to the best fitness centers in your area.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90">
                Sign Up Now
              </Button>
            </Link>
            <Link to="/gyms">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20">
                Browse All Gyms
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="mt-12 flex justify-center">
        <Link to="/" className="flex items-center text-primary hover:text-primary/80 transition-colors">
          <ArrowLeft className="h-4 w-4 mr-2" />
          <span>Back to Home</span>
        </Link>
      </div>
    </div>
  );
};

export default PremiumGyms;
