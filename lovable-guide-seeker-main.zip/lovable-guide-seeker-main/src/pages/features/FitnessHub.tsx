
import { useState } from "react";
import { motion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "react-router-dom";
import { ArrowLeft, Activity, Heart, BarChart2 } from "lucide-react";
import BMICalculator from "@/components/fitness/BMICalculator";
import CalorieCalculator from "@/components/fitness/CalorieCalculator";
import HealthCheck from "@/components/fitness/HealthCheck";
import FitnessTracking from "@/components/FitnessTracking";

const FitnessHub = () => {
  const [activeTab, setActiveTab] = useState("tracking");
  
  return (
    <div className="container max-w-7xl py-12 px-4 sm:px-6 lg:py-16 lg:px-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
        <Link to="/" className="hover:text-primary transition-colors">Home</Link>
        <span>/</span>
        <span>Fitness Hub</span>
      </div>

      {/* Hero section */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center mb-12"
      >
        <h1 className="text-4xl md:text-6xl font-bold mb-6 text-gradient-primary">
          Complete Fitness Toolkit
        </h1>
        <p className="max-w-2xl mx-auto text-xl text-muted-foreground">
          Access everything you need to monitor and improve your fitness journey in one place.
        </p>
      </motion.div>

      {/* Fitness Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-16">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-4">
          <TabsTrigger value="tracking" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            <span>Fitness Tracking</span>
          </TabsTrigger>
          <TabsTrigger value="bmi" className="flex items-center gap-2">
            <BarChart2 className="h-4 w-4" />
            <span>BMI Calculator</span>
          </TabsTrigger>
          <TabsTrigger value="calories" className="flex items-center gap-2">
            <BarChart2 className="h-4 w-4" />
            <span>Calorie Calculator</span>
          </TabsTrigger>
          <TabsTrigger value="health" className="flex items-center gap-2">
            <Heart className="h-4 w-4" />
            <span>Health Check</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="tracking" className="mt-8">
          <div className="bg-card p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold mb-6">Track Your Fitness Progress</h2>
            <FitnessTracking />
          </div>
        </TabsContent>
        
        <TabsContent value="bmi" className="mt-8">
          <div className="max-w-2xl mx-auto">
            <BMICalculator />
          </div>
        </TabsContent>
        
        <TabsContent value="calories" className="mt-8">
          <div className="max-w-2xl mx-auto">
            <CalorieCalculator />
          </div>
        </TabsContent>
        
        <TabsContent value="health" className="mt-8">
          <div className="max-w-2xl mx-auto">
            <HealthCheck />
          </div>
        </TabsContent>
      </Tabs>

      {/* Feature highlights */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16"
      >
        {[
          {
            title: "180+ Metrics Tracking",
            description: "Monitor everything from steps and calories to advanced metrics like VO2 max and recovery rate."
          },
          {
            title: "Personalized Insights",
            description: "Get AI-powered recommendations based on your unique fitness profile and goals."
          },
          {
            title: "Connect Any Device",
            description: "Seamlessly integrate with popular wearables like Fitbit, Apple Watch, and Garmin."
          }
        ].map((feature, i) => (
          <div 
            key={i}
            className="bg-card p-6 rounded-xl border shadow-sm hover:shadow-md transition-shadow"
          >
            <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
            <p className="text-muted-foreground">{feature.description}</p>
          </div>
        ))}
      </motion.div>

      {/* CTA Section */}
      <div className="bg-gradient-to-br from-primary/20 to-purple-600/20 p-8 rounded-2xl text-center mb-8">
        <h2 className="text-2xl font-bold mb-4">Ready to start your fitness journey?</h2>
        <p className="mb-6 max-w-2xl mx-auto">
          Join thousands of members who have transformed their lives with our comprehensive fitness tools.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Link to="/register">
            <button className="bg-primary text-primary-foreground hover:bg-primary/90 px-6 py-2 rounded-lg">
              Sign Up Now
            </button>
          </Link>
          <Link to="/gyms">
            <button className="bg-secondary text-secondary-foreground hover:bg-secondary/90 px-6 py-2 rounded-lg">
              Find a Gym
            </button>
          </Link>
        </div>
      </div>

      <div className="flex justify-center">
        <Link to="/" className="flex items-center text-primary hover:text-primary/80 transition-colors">
          <ArrowLeft className="h-4 w-4 mr-2" />
          <span>Back to Home</span>
        </Link>
      </div>
    </div>
  );
};

export default FitnessHub;
