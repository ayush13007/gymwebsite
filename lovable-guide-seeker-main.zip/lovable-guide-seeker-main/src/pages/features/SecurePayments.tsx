
import { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, CreditCard, Shield, LockKeyhole, CheckCircle, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";

// Mock payment plans
const plans = [
  {
    id: "basic",
    name: "Basic Plan",
    price: 29,
    period: "monthly",
    features: [
      "Access to all basic gym equipment",
      "2 free group classes per month",
      "Locker access",
      "Online booking system"
    ]
  },
  {
    id: "premium",
    name: "Premium Plan",
    price: 49,
    period: "monthly",
    features: [
      "Access to all gym equipment",
      "Unlimited group classes",
      "Personal locker",
      "1 session with personal trainer per month",
      "Access to sauna and spa",
      "Priority booking"
    ],
    popular: true
  },
  {
    id: "elite",
    name: "Elite Plan",
    price: 89,
    period: "monthly",
    features: [
      "24/7 access to all gym locations",
      "Unlimited group classes",
      "Personal locker with amenities",
      "4 sessions with personal trainer per month",
      "Access to sauna, spa, and swimming pool",
      "Nutritional consultation",
      "Priority booking with no cancellation fees"
    ]
  }
];

const SecurePayments = () => {
  const [selectedPlan, setSelectedPlan] = useState(plans[1]);
  const [paymentMethod, setPaymentMethod] = useState("card");

  return (
    <div className="container max-w-7xl py-12 px-4 sm:px-6 lg:py-16 lg:px-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
        <Link to="/" className="hover:text-primary transition-colors">Home</Link>
        <span>/</span>
        <span>Secure Payments</span>
      </div>

      {/* Hero section */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center mb-16"
      >
        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          Secure Payment Solutions
        </h1>
        <p className="max-w-2xl mx-auto text-xl text-muted-foreground">
          Pay securely for your bookings with our integrated payment system powered by Razorpay.
        </p>
      </motion.div>

      {/* Membership Plans */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold mb-10 text-center">Choose Your Membership Plan</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card 
                className={`border-none overflow-hidden h-full relative transition-all ${
                  selectedPlan.id === plan.id 
                    ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/20' 
                    : 'bg-white/5 backdrop-blur-sm hover:bg-white/10'
                }`}
              >
                {plan.popular && (
                  <div className="absolute top-0 right-0">
                    <div className="bg-yellow-500 text-white text-xs font-bold px-3 py-1 transform rotate-45 translate-x-6 -translate-y-1">
                      POPULAR
                    </div>
                  </div>
                )}
                <CardHeader>
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <div className="mt-2">
                    <span className="text-4xl font-bold">${plan.price}</span>
                    <span className="text-sm ml-1">/{plan.period}</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start">
                        <CheckCircle className="h-5 w-5 mr-2 shrink-0 text-green-500" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button
                    className={`w-full ${
                      selectedPlan.id === plan.id 
                        ? 'bg-white text-primary hover:bg-white/90' 
                        : ''
                    }`}
                    variant={selectedPlan.id === plan.id ? 'default' : 'outline'}
                    onClick={() => setSelectedPlan(plan)}
                  >
                    {selectedPlan.id === plan.id ? 'Selected' : 'Select Plan'}
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Payment Process */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.6 }}
        className="mb-16"
      >
        <h2 className="text-3xl font-bold mb-10 text-center">Secure Payment Process</h2>
        
        <div className="max-w-3xl mx-auto bg-white/5 backdrop-blur-sm p-8 rounded-xl">
          <div className="mb-8">
            <h3 className="text-2xl font-semibold mb-4">Selected Plan: {selectedPlan.name}</h3>
            <p className="text-muted-foreground mb-2">Total Amount: ${selectedPlan.price}</p>
            <p className="text-muted-foreground">Billing Cycle: {selectedPlan.period}</p>
          </div>
          
          <Tabs value={paymentMethod} onValueChange={setPaymentMethod}>
            <TabsList className="grid grid-cols-3 mb-8">
              <TabsTrigger value="card">Credit Card</TabsTrigger>
              <TabsTrigger value="upi">UPI</TabsTrigger>
              <TabsTrigger value="netbanking">Net Banking</TabsTrigger>
            </TabsList>
            
            <TabsContent value="card" className="space-y-4">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm mb-1 block">Cardholder Name</label>
                    <Input placeholder="John Doe" />
                  </div>
                  <div>
                    <label className="text-sm mb-1 block">Card Number</label>
                    <Input placeholder="4242 4242 4242 4242" />
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="col-span-1">
                    <label className="text-sm mb-1 block">Expiry Date</label>
                    <Input placeholder="MM/YY" />
                  </div>
                  <div className="col-span-1">
                    <label className="text-sm mb-1 block">CVV</label>
                    <Input placeholder="123" />
                  </div>
                  <div className="col-span-1">
                    <label className="text-sm mb-1 block">Zip Code</label>
                    <Input placeholder="10001" />
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="upi" className="space-y-4">
              <div>
                <label className="text-sm mb-1 block">UPI ID</label>
                <Input placeholder="yourname@upi" />
              </div>
              <div className="text-center text-muted-foreground py-4">
                <p>Enter your UPI ID and click Pay Now to complete the payment.</p>
              </div>
            </TabsContent>
            
            <TabsContent value="netbanking" className="space-y-4">
              <div>
                <label className="text-sm mb-1 block">Select Bank</label>
                <select className="w-full p-2 rounded-md border border-border bg-transparent">
                  <option>Select your bank</option>
                  <option>HDFC Bank</option>
                  <option>State Bank of India</option>
                  <option>ICICI Bank</option>
                  <option>Axis Bank</option>
                  <option>Yes Bank</option>
                </select>
              </div>
              <div className="text-center text-muted-foreground py-4">
                <p>You will be redirected to your bank's website to complete the payment.</p>
              </div>
            </TabsContent>
            
            <div className="mt-6">
              <Button 
                className="w-full" 
                size="lg"
                onClick={() => alert("This is a demo. In a real implementation, this would integrate with Razorpay's payment system.")}
              >
                <LockKeyhole className="h-4 w-4 mr-2" />
                Pay Securely Now
              </Button>
              <div className="flex items-center justify-center mt-4 text-xs text-muted-foreground">
                <Shield className="h-4 w-4 mr-1" />
                <span>Secured by Razorpay | 256-bit encryption</span>
              </div>
            </div>
          </Tabs>
        </div>
      </motion.div>

      {/* Security Features */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold mb-10 text-center">Payment Security Features</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              icon: <Shield className="h-6 w-6" />,
              title: "Bank-Level Security",
              description: "Your payment details are protected with the highest level of security standards."
            },
            {
              icon: <LockKeyhole className="h-6 w-6" />,
              title: "End-to-End Encryption",
              description: "All your transaction data is encrypted with 256-bit SSL encryption."
            },
            {
              icon: <AlertCircle className="h-6 w-6" />,
              title: "Fraud Protection",
              description: "Advanced fraud detection systems to keep your transactions safe."
            }
          ].map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + i * 0.1, duration: 0.6 }}
              className="bg-white/5 backdrop-blur-sm p-6 rounded-lg"
            >
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Payment Methods */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.6 }}
        className="mb-16"
      >
        <h2 className="text-3xl font-bold mb-6 text-center">Accepted Payment Methods</h2>
        <p className="text-center text-muted-foreground mb-8 max-w-2xl mx-auto">
          We support a wide range of payment options to make your gym membership purchase as convenient as possible.
        </p>
        
        <div className="flex flex-wrap justify-center gap-8 items-center">
          <div className="py-4 px-8 bg-white/5 backdrop-blur-sm rounded-lg">
            <CreditCard className="h-8 w-8" />
            <span className="block text-center mt-2">Credit Card</span>
          </div>
          <div className="py-4 px-8 bg-white/5 backdrop-blur-sm rounded-lg">
            <CreditCard className="h-8 w-8" />
            <span className="block text-center mt-2">Debit Card</span>
          </div>
          <div className="py-4 px-8 bg-white/5 backdrop-blur-sm rounded-lg">
            <span className="text-xl font-bold">UPI</span>
            <span className="block text-center mt-2">UPI Apps</span>
          </div>
          <div className="py-4 px-8 bg-white/5 backdrop-blur-sm rounded-lg">
            <span className="text-xl font-bold">NET</span>
            <span className="block text-center mt-2">Net Banking</span>
          </div>
          <div className="py-4 px-8 bg-white/5 backdrop-blur-sm rounded-lg">
            <span className="text-xl font-bold">EMI</span>
            <span className="block text-center mt-2">EMI Options</span>
          </div>
        </div>
      </motion.div>

      {/* FAQ */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold mb-10 text-center">Payment FAQs</h2>
        
        <div className="max-w-3xl mx-auto space-y-6">
          {[
            {
              question: "How secure is the payment system?",
              answer: "Our payment system is powered by Razorpay, which uses bank-grade security measures including 256-bit encryption and is PCI DSS compliant."
            },
            {
              question: "Can I cancel my subscription?",
              answer: "Yes, you can cancel your subscription at any time from your account dashboard. Refunds are processed according to our refund policy."
            },
            {
              question: "What happens if my payment fails?",
              answer: "If your payment fails, you'll receive a notification with details. You can retry the payment or choose a different payment method."
            },
            {
              question: "Do you store my payment details?",
              answer: "We do not store your complete card details. All sensitive payment information is handled directly by our payment processor."
            }
          ].map((faq, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + i * 0.1, duration: 0.5 }}
              className="bg-white/5 backdrop-blur-sm p-6 rounded-lg"
            >
              <h3 className="text-xl font-semibold mb-2">{faq.question}</h3>
              <p className="text-muted-foreground">{faq.answer}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="bg-gradient-to-r from-primary to-purple-600 rounded-3xl p-8 md:p-12 text-white">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to start your fitness journey?</h2>
          <p className="text-lg mb-8 text-white/90">
            Choose a plan that works for you and join thousands of satisfied members.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90">
                Sign Up Now
              </Button>
            </Link>
            <Link to="/gyms">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20">
                Explore Gyms First
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="mt-12 flex justify-center">
        <Link to="/" className="flex items-center text-primary hover:text-primary/80 transition-colors">
          <ArrowLeft className="h-4 w-4 mr-2" />
          <span>Back to Home</span>
        </Link>
      </div>
    </div>
  );
};

export default SecurePayments;
