
import { useEffect, useState } from 'react';
import LazyLoadedThreeDGymView from '@/components/LazyLoadedThreeDGymView';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from '@/components/ui/sonner';

const ExploreIn3D = () => {
  const [currentGymIndex, setCurrentGymIndex] = useState(0);
  
  const gyms = [
    {
      id: '1',
      name: 'Elite Fitness Center',
      location: 'Downtown',
      description: 'State-of-the-art equipment with dedicated areas for various workout styles.',
      rating: 4.8
    },
    {
      id: '2',
      name: 'PowerHouse Gym',
      location: 'Westside',
      description: 'Specializing in strength training with premium heavy-duty equipment.',
      rating: 4.7
    },
    {
      id: '3',
      name: 'Zen Fitness Studio',
      location: 'Eastside',
      description: 'A balanced approach to fitness with both cardio and strength options.',
      rating: 4.9
    }
  ];

  // Notify user about 3D exploration feature
  useEffect(() => {
    toast("Explore gyms in immersive 3D", {
      description: "Navigate through our partner facilities before visiting in person",
      duration: 5000,
    });
  }, []);

  const nextGym = () => {
    setCurrentGymIndex((prev) => (prev + 1) % gyms.length);
  };

  const prevGym = () => {
    setCurrentGymIndex((prev) => (prev - 1 + gyms.length) % gyms.length);
  };

  return (
    <div className="container py-12">
      <div className="flex flex-col space-y-6">
        <div className="text-center space-y-3">
          <h1 className="text-4xl font-bold">Explore Gyms in 3D</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Take a virtual tour of our partner facilities before making your decision.
          </p>
        </div>

        <div className="rounded-xl overflow-hidden border bg-card shadow-lg">
          <LazyLoadedThreeDGymView gym={gyms[currentGymIndex]} />
          
          <div className="p-4 flex justify-between items-center bg-muted/50">
            <Button 
              variant="outline" 
              onClick={prevGym}
              disabled={gyms.length <= 1}
            >
              Previous Gym
            </Button>
            <span className="text-sm font-medium">
              {currentGymIndex + 1} of {gyms.length}
            </span>
            <Button 
              variant="default" 
              onClick={nextGym}
              disabled={gyms.length <= 1}
            >
              Next Gym
            </Button>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mt-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center space-y-2">
                <div className="rounded-full bg-primary/10 p-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                </div>
                <h3 className="font-medium text-lg">Immersive Experience</h3>
                <p className="text-muted-foreground text-sm">
                  Explore every corner of the gym as if you were there in person.
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center space-y-2">
                <div className="rounded-full bg-primary/10 p-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                  </svg>
                </div>
                <h3 className="font-medium text-lg">Compare Facilities</h3>
                <p className="text-muted-foreground text-sm">
                  View and compare different gym layouts and available equipment.
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center space-y-2">
                <div className="rounded-full bg-primary/10 p-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
                  </svg>
                </div>
                <h3 className="font-medium text-lg">Make Informed Decisions</h3>
                <p className="text-muted-foreground text-sm">
                  Find the perfect gym that matches your specific fitness needs.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ExploreIn3D;
