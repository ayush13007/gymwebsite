
import { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Calendar as CalendarIcon, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Card } from "@/components/ui/card";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

const EasyBooking = () => {
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<string | null>(null);

  const timeSlots = [
    "06:00 AM", "07:00 AM", "08:00 AM", "09:00 AM", 
    "10:00 AM", "11:00 AM", "12:00 PM", "01:00 PM",
    "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM",
    "06:00 PM", "07:00 PM", "08:00 PM", "09:00 PM"
  ];

  const workoutTypes = [
    "Personal Training",
    "Group Fitness",
    "Open Gym",
    "Yoga Class",
    "CrossFit",
    "Swimming"
  ];

  const benefits = [
    {
      title: "No More Waiting",
      description: "Skip the lines and reserve your spot in advance, ensuring you never miss a workout due to overcrowding."
    },
    {
      title: "Flexible Scheduling",
      description: "Book sessions around your busy schedule, with options from early morning to late evening."
    },
    {
      title: "Smart Reminders",
      description: "Get notifications before your session so you never forget a scheduled workout."
    },
    {
      title: "Easy Rescheduling",
      description: "Life happens. Reschedule your sessions with just a few taps when plans change."
    }
  ];

  return (
    <div className="container max-w-7xl py-12 px-4 sm:px-6 lg:py-16 lg:px-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
        <Link to="/" className="hover:text-primary transition-colors">Home</Link>
        <span>/</span>
        <span>Easy Booking</span>
      </div>

      {/* Hero section */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center mb-16"
      >
        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          Seamless Gym Session Booking
        </h1>
        <p className="max-w-2xl mx-auto text-xl text-muted-foreground">
          Book your sessions in advance with our intuitive calendar system and never miss a workout.
        </p>
      </motion.div>

      {/* Booking Demo */}
      <div className="mb-20">
        <h2 className="text-3xl font-bold mb-10 text-center">Try Our Booking System</h2>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="lg:col-span-5 bg-white/5 backdrop-blur-sm p-6 rounded-xl"
          >
            <h3 className="text-xl font-semibold mb-6">Select Date & Time</h3>
            
            {/* Date picker */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-2">Date</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : <span>Select a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            {/* Time slots */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-2">Time Slot</label>
              <div className="grid grid-cols-4 gap-2">
                {timeSlots.map((time, i) => (
                  <button
                    key={i}
                    className={cn(
                      "py-2 px-1 text-xs sm:text-sm rounded-md transition-colors",
                      selectedTime === time 
                        ? "bg-primary text-primary-foreground" 
                        : "bg-muted/30 hover:bg-muted"
                    )}
                    onClick={() => setSelectedTime(time)}
                  >
                    {time}
                  </button>
                ))}
              </div>
            </div>
            
            {/* Workout type */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-2">Workout Type</label>
              <div className="grid grid-cols-2 gap-2">
                {workoutTypes.map((type, i) => (
                  <button
                    key={i}
                    className={cn(
                      "py-2 px-3 text-sm rounded-md transition-colors",
                      selectedType === type 
                        ? "bg-primary text-primary-foreground" 
                        : "bg-muted/30 hover:bg-muted"
                    )}
                    onClick={() => setSelectedType(type)}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>
            
            {/* Book button */}
            <Button 
              disabled={!date || !selectedTime || !selectedType} 
              className="w-full mt-4"
              onClick={() => {
                alert(`Demo booking created for ${format(date!, "PPP")} at ${selectedTime} for ${selectedType}`);
              }}
            >
              Book Session
            </Button>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="lg:col-span-7"
          >
            <h3 className="text-xl font-semibold mb-6">Your Selection</h3>
            <div className="bg-white/5 backdrop-blur-sm p-6 rounded-xl mb-6">
              {date && selectedTime && selectedType ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b border-border pb-4">
                    <span className="text-muted-foreground">Date:</span>
                    <span className="font-medium">{format(date, "MMMM d, yyyy")}</span>
                  </div>
                  <div className="flex items-center justify-between border-b border-border pb-4">
                    <span className="text-muted-foreground">Time:</span>
                    <span className="font-medium">{selectedTime}</span>
                  </div>
                  <div className="flex items-center justify-between border-b border-border pb-4">
                    <span className="text-muted-foreground">Workout Type:</span>
                    <span className="font-medium">{selectedType}</span>
                  </div>
                  <div className="flex items-center justify-between pt-2">
                    <span className="text-muted-foreground">Status:</span>
                    <span className="inline-flex items-center text-green-500">
                      <CheckCircle className="h-4 w-4 mr-1" /> Available
                    </span>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  Select a date, time and workout type to see your booking details.
                </div>
              )}
            </div>
            
            <div className="bg-white/5 backdrop-blur-sm p-6 rounded-xl">
              <h3 className="text-xl font-semibold mb-4">How It Works</h3>
              <ol className="space-y-4">
                <li className="flex items-start">
                  <span className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm mr-3">1</span>
                  <span>Choose your preferred date from the calendar</span>
                </li>
                <li className="flex items-start">
                  <span className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm mr-3">2</span>
                  <span>Select an available time slot that fits your schedule</span>
                </li>
                <li className="flex items-start">
                  <span className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm mr-3">3</span>
                  <span>Choose your workout type or class</span>
                </li>
                <li className="flex items-start">
                  <span className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm mr-3">4</span>
                  <span>Confirm your booking and receive a confirmation</span>
                </li>
                <li className="flex items-start">
                  <span className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white text-sm mr-3">5</span>
                  <span>Get reminders before your session</span>
                </li>
              </ol>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Benefits */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold mb-10 text-center">Benefits of Our Booking System</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((benefit, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + i * 0.1, duration: 0.6 }}
            >
              <Card className="h-full border-none bg-white/5 backdrop-blur-sm">
                <div className="p-6">
                  <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <CheckCircle className="h-6 w-6" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
                  <p className="text-muted-foreground">{benefit.description}</p>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="bg-gradient-to-r from-primary to-purple-600 rounded-3xl p-8 md:p-12 text-white">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to streamline your fitness routine?</h2>
          <p className="text-lg mb-8 text-white/90">
            Sign up now to start booking your gym sessions and classes with ease.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90">
                Create Free Account
              </Button>
            </Link>
            <Link to="/gyms">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20">
                Browse Gyms
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="mt-12 flex justify-center">
        <Link to="/" className="flex items-center text-primary hover:text-primary/80 transition-colors">
          <ArrowLeft className="h-4 w-4 mr-2" />
          <span>Back to Home</span>
        </Link>
      </div>
    </div>
  );
};

export default EasyBooking;
