
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowLeft, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ReviewsSection from "@/components/community/ReviewsSection";

const Community = () => {
  return (
    <div className="container max-w-7xl py-12 px-4 sm:px-6 lg:py-16 lg:px-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
        <Link to="/" className="hover:text-primary transition-colors">Home</Link>
        <span>/</span>
        <span>Community</span>
      </div>
      
      {/* Header */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center mb-16"
      >
        <div className="flex items-center justify-center gap-2 mb-4">
          <Users className="h-8 w-8 text-primary" />
          <h1 className="text-4xl md:text-6xl font-bold text-gradient-primary">Our Fitness Community</h1>
        </div>
        <p className="max-w-2xl mx-auto text-xl text-muted-foreground">
          Join over 250,000 members sharing their fitness journeys, reviews, and success stories
        </p>
      </motion.div>

      {/* Stats Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16"
      >
        {[
          { label: "Members", value: "250K+" },
          { label: "Reviews", value: "200K+" },
          { label: "Success Stories", value: "15K+" },
          { label: "Gyms", value: "500+" },
        ].map((stat, i) => (
          <div 
            key={i} 
            className="bg-accent/50 p-6 rounded-xl text-center"
          >
            <p className="text-3xl md:text-4xl font-bold text-primary">{stat.value}</p>
            <p className="text-sm md:text-base text-muted-foreground">{stat.label}</p>
          </div>
        ))}
      </motion.div>

      {/* Community Tabs */}
      <Tabs defaultValue="reviews" className="mb-16">
        <TabsList className="w-full grid grid-cols-3 mb-8">
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
          <TabsTrigger value="discussions">Discussions</TabsTrigger>
          <TabsTrigger value="success">Success Stories</TabsTrigger>
        </TabsList>
        
        <TabsContent value="reviews" className="mt-4">
          <ReviewsSection />
        </TabsContent>
        
        <TabsContent value="discussions" className="mt-4">
          <div className="text-center py-12">
            <h3 className="text-2xl font-semibold mb-4">Join the Conversation</h3>
            <p className="text-muted-foreground mb-6">
              Our discussion forum will be launching soon. Sign up to be notified!
            </p>
            <Button>Get Notified</Button>
          </div>
        </TabsContent>
        
        <TabsContent value="success" className="mt-4">
          <div className="text-center py-12">
            <h3 className="text-2xl font-semibold mb-4">Success Stories</h3>
            <p className="text-muted-foreground mb-6">
              Read inspiring transformation journeys from our community members.
              Coming soon!
            </p>
            <Button>Get Notified</Button>
          </div>
        </TabsContent>
      </Tabs>

      {/* Community CTA */}
      <div className="bg-gradient-to-br from-primary/20 to-purple-600/20 p-8 rounded-2xl text-center mb-8">
        <h2 className="text-2xl font-bold mb-4">Join our fitness community today</h2>
        <p className="mb-6 max-w-2xl mx-auto">
          Connect with like-minded fitness enthusiasts, share your journey, and get support from our community of experts.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Link to="/register">
            <Button className="min-w-[150px]">Sign Up Now</Button>
          </Link>
        </div>
      </div>

      <div className="flex justify-center mt-12">
        <Link to="/" className="flex items-center text-primary hover:text-primary/80 transition-colors">
          <ArrowLeft className="h-4 w-4 mr-2" />
          <span>Back to Home</span>
        </Link>
      </div>
    </div>
  );
};

export default Community;
