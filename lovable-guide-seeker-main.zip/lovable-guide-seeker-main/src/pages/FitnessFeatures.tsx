
import { useState } from "react";
import { motion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "react-router-dom";
import { ArrowLeft, Activity, Heart, BarChart2, Dumbbell, MapPin } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import BMICalculator from "@/components/fitness/BMICalculator";
import CalorieCalculator from "@/components/fitness/CalorieCalculator";
import HealthCheck from "@/components/fitness/HealthCheck";
import FitnessTracking from "@/components/FitnessTracking";
import LocationFinder from "@/components/LocationFinder";

const FitnessFeatures = () => {
  const [activeTab, setActiveTab] = useState("tracking");
  
  return (
    <div className="container max-w-7xl py-12 px-4 sm:px-6 lg:py-16 lg:px-8">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
        <Link to="/" className="hover:text-primary transition-colors">Home</Link>
        <span>/</span>
        <span>Fitness Features</span>
      </div>

      {/* Hero section */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center mb-12"
      >
        <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-600">
          Complete Fitness Toolkit
        </h1>
        <p className="max-w-2xl mx-auto text-xl text-muted-foreground">
          Access all our fitness features in one place to monitor and improve your fitness journey.
        </p>
      </motion.div>

      {/* Fitness Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-16">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
          <TabsTrigger value="tracking" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            <span>Fitness Tracking</span>
          </TabsTrigger>
          <TabsTrigger value="bmi" className="flex items-center gap-2">
            <BarChart2 className="h-4 w-4" />
            <span>BMI Calculator</span>
          </TabsTrigger>
          <TabsTrigger value="calories" className="flex items-center gap-2">
            <BarChart2 className="h-4 w-4" />
            <span>Calorie Calculator</span>
          </TabsTrigger>
          <TabsTrigger value="health" className="flex items-center gap-2">
            <Heart className="h-4 w-4" />
            <span>Health Check</span>
          </TabsTrigger>
          <TabsTrigger value="location" className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            <span>Find Gyms</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="tracking" className="mt-8">
          <div className="bg-card p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold mb-6">Track Your Fitness Progress</h2>
            <FitnessTracking />
          </div>
        </TabsContent>
        
        <TabsContent value="bmi" className="mt-8">
          <div className="max-w-2xl mx-auto">
            <BMICalculator />
          </div>
        </TabsContent>
        
        <TabsContent value="calories" className="mt-8">
          <div className="max-w-2xl mx-auto">
            <CalorieCalculator />
          </div>
        </TabsContent>
        
        <TabsContent value="health" className="mt-8">
          <div className="max-w-2xl mx-auto">
            <HealthCheck />
          </div>
        </TabsContent>

        <TabsContent value="location" className="mt-8">
          <div className="w-full">
            <LocationFinder />
          </div>
        </TabsContent>
      </Tabs>

      {/* Feature highlights */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16"
      >
        {[
          {
            title: "180+ Metrics Tracking",
            description: "Monitor everything from steps and calories to advanced metrics like VO2 max and recovery rate.",
            icon: Activity
          },
          {
            title: "Personalized Insights",
            description: "Get AI-powered recommendations based on your unique fitness profile and goals.",
            icon: Heart
          },
          {
            title: "Connect Any Device",
            description: "Seamlessly integrate with popular wearables like Fitbit, Apple Watch, and Garmin.",
            icon: Dumbbell
          }
        ].map((feature, i) => (
          <Card 
            key={i}
            className="bg-card p-6 rounded-xl border shadow-sm hover:shadow-md transition-shadow"
          >
            <CardHeader className="pb-2 flex flex-row items-center gap-2">
              <feature.icon className="h-6 w-6 text-primary" />
              <CardTitle>{feature.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{feature.description}</p>
            </CardContent>
          </Card>
        ))}
      </motion.div>

      {/* CTA Section */}
      <div className="bg-gradient-to-br from-primary/20 to-purple-600/20 p-8 rounded-2xl text-center mb-8">
        <h2 className="text-2xl font-bold mb-4">Ready to start your fitness journey?</h2>
        <p className="mb-6 max-w-2xl mx-auto">
          Join thousands of members who have transformed their lives with our comprehensive fitness tools.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Link to="/register" className="bg-primary text-primary-foreground hover:bg-primary/90 px-6 py-2 rounded-lg">
            Sign Up Now
          </Link>
          <Link to="/gyms" className="bg-secondary text-secondary-foreground hover:bg-secondary/90 px-6 py-2 rounded-lg">
            Find a Gym
          </Link>
        </div>
      </div>

      <div className="flex justify-center">
        <Link to="/" className="flex items-center text-primary hover:text-primary/80 transition-colors">
          <ArrowLeft className="h-4 w-4 mr-2" />
          <span>Back to Home</span>
        </Link>
      </div>
    </div>
  );
};

export default FitnessFeatures;
