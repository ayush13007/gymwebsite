
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { Label } from "@/components/ui/label";
import { Navigation, Search, MapPin, Calendar as CalendarIcon } from "lucide-react";
import LocationFinder from "@/components/LocationFinder";

const Gyms = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [date, setDate] = useState<Date | undefined>(new Date());
  
  return (
    <div className="py-8">
      <div className="container">
        <h1 className="text-4xl font-bold mb-2 text-center">Find Your Perfect Gym</h1>
        <p className="text-muted-foreground text-center mb-8 max-w-2xl mx-auto">
          Search for gyms in your area, filter by amenities, and book your next workout session.
        </p>
        
        {/* Search and Filters */}
        <div className="bg-muted p-6 rounded-lg mb-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="search" className="mb-2 block">Search</Label>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="Gym name or keyword"
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="location" className="mb-2 block">Location</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="location"
                  placeholder="Enter city or zip code"
                  className="pl-10"
                />
              </div>
            </div>
            
            <div>
              <Label className="mb-2 block">Date</Label>
              <div className="bg-background rounded-md border p-2">
                <div className="flex items-center gap-2">
                  <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">
                    {date ? date.toLocaleDateString() : "Select date"}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="flex items-end">
              <Button className="w-full">Search Gyms</Button>
            </div>
          </div>
          
          <div className="mt-4 flex justify-center">
            <Button variant="outline" className="flex items-center gap-2">
              <Navigation className="h-4 w-4" />
              Use My Current Location
            </Button>
          </div>
        </div>
        
        {/* Location Finder Component */}
        <LocationFinder />
        
        {/* Calendar Section */}
        <div className="mt-12 bg-muted p-6 rounded-lg">
          <h2 className="text-2xl font-bold mb-6 text-center">Book Your Slot</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Select Date & Time</CardTitle>
              </CardHeader>
              <CardContent className="flex justify-center">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  className="rounded-md border"
                />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Available Slots</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-2">
                  {["07:00 AM", "09:00 AM", "11:00 AM", "01:00 PM", "03:00 PM", "05:00 PM", "07:00 PM", "09:00 PM"].map((time) => (
                    <Button key={time} variant="outline" className="text-sm">
                      {time}
                    </Button>
                  ))}
                </div>
                <Button className="w-full mt-6">Book Selected Slot</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Gyms;
