
import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import BlogCard, { BlogPost } from "@/components/blog/BlogCard";
import { Book, Search } from "lucide-react";

// Mock blog data
const mockBlogPosts: BlogPost[] = [
  {
    id: "1",
    title: "The Ultimate Guide to Building Muscle While Staying Lean",
    excerpt: "Learn the science-backed methods to build muscle mass without adding unwanted fat. Includes workout plans and nutrition advice.",
    image: "https://images.unsplash.com/photo-1605296867304-46d5465a13f1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    author: {
      name: "Alex Smith",
      avatar: "https://randomuser.me/api/portraits/men/32.jpg",
    },
    publishedAt: new Date("2025-04-15"),
    category: "Strength Training",
    readTime: 8,
  },
  {
    id: "2",
    title: "How to Find Your Perfect Gym: What to Look For",
    excerpt: "With so many gym options available, it can be hard to choose. This guide helps you identify what factors matter most for your fitness journey.",
    image: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    author: {
      name: "Jessica Lee",
      avatar: "https://randomuser.me/api/portraits/women/44.jpg",
    },
    publishedAt: new Date("2025-04-12"),
    category: "Gym Selection",
    readTime: 6,
  },
  {
    id: "3",
    title: "The Mental Benefits of Regular Exercise: Beyond Physical Health",
    excerpt: "Regular physical activity doesn't just improve your body - it has profound effects on mental health, cognitive function, and emotional wellbeing.",
    image: "https://images.unsplash.com/photo-1549576490-b0b4831ef60a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    author: {
      name: "Dr. Michael Chen",
      avatar: "https://randomuser.me/api/portraits/men/52.jpg",
    },
    publishedAt: new Date("2025-04-08"),
    category: "Mental Health",
    readTime: 10,
  },
  {
    id: "4",
    title: "5 Nutrition Myths Debunked by Science",
    excerpt: "From carbs to protein timing, we break down common nutrition myths that might be holding back your fitness progress and health goals.",
    image: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    author: {
      name: "Emma Wilson",
      avatar: "https://randomuser.me/api/portraits/women/33.jpg",
    },
    publishedAt: new Date("2025-04-05"),
    category: "Nutrition",
    readTime: 7,
  },
  {
    id: "5",
    title: "The Best Gym Equipment for Home Workouts in 2025",
    excerpt: "Transform any space into an effective home gym with our top equipment picks that balance versatility, quality, and value.",
    image: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    author: {
      name: "Carlos Diaz",
      avatar: "https://randomuser.me/api/portraits/men/67.jpg",
    },
    publishedAt: new Date("2025-04-01"),
    category: "Equipment",
    readTime: 9,
  },
  {
    id: "6",
    title: "GymZone Premium: Is the Membership Worth It?",
    excerpt: "An honest review of GymZone Premium membership benefits, facilities, and whether the additional cost delivers real value.",
    image: "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    author: {
      name: "Linda Parker",
      avatar: "https://randomuser.me/api/portraits/women/28.jpg",
    },
    publishedAt: new Date("2025-03-28"),
    category: "Reviews",
    readTime: 8,
  },
];

const categories = [
  "All",
  "Strength Training",
  "Cardio",
  "Nutrition",
  "Reviews",
  "Mental Health",
  "Equipment",
];

const Blog = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredPosts = mockBlogPosts.filter((post) => {
    const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         post.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === "All" || post.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="container max-w-7xl py-12 px-4 sm:px-6 lg:py-16 lg:px-8">
      {/* Header */}
      <div className="mb-12 text-center">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex items-center justify-center gap-2 mb-4"
        >
          <Book className="h-8 w-8 text-primary" />
          <h1 className="text-4xl font-bold text-gradient-primary">GymZone Blog</h1>
        </motion.div>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Expert insights, workout tips, and the latest in fitness trends
        </p>
      </div>

      {/* Featured post */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="mb-16"
      >
        <div className="relative h-[400px] rounded-2xl overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1517838277536-f5f99be501cd?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
            alt="Featured post"
            className="absolute inset-0 object-cover w-full h-full"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
          <div className="absolute bottom-0 left-0 p-8 text-white">
            <span className="bg-primary px-3 py-1 rounded-full text-xs font-medium mb-4 inline-block">
              FEATURED
            </span>
            <h2 className="text-3xl font-bold mb-4 max-w-2xl">
              The Science-Backed Approach to Fitness That's Changing Lives
            </h2>
            <div className="flex items-center text-sm">
              <img 
                src="https://randomuser.me/api/portraits/women/65.jpg"
                alt="Author"
                className="w-10 h-10 rounded-full mr-3 border-2 border-white"
              />
              <div>
                <p className="font-medium">Dr. Sarah Johnson</p>
                <p>April 18, 2025 · 12 min read</p>
              </div>
            </div>
            <Link to="/blog/featured">
              <Button variant="secondary" className="mt-6">
                Read Article
              </Button>
            </Link>
          </div>
        </div>
      </motion.div>

      {/* Search and filters */}
      <div className="mb-8 flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="absolute top-2.5 left-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search articles..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Tabs
          value={activeCategory}
          onValueChange={setActiveCategory}
          className="w-full md:w-auto"
        >
          <TabsList className="h-auto flex flex-wrap">
            {categories.map((category) => (
              <TabsTrigger key={category} value={category} className="text-xs md:text-sm">
                {category}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </div>

      {/* Blog posts grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
        {filteredPosts.map((post) => (
          <motion.div
            key={post.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * parseInt(post.id) }}
          >
            <BlogCard post={post} />
          </motion.div>
        ))}
      </div>

      {/* Newsletter signup */}
      <div className="bg-accent/50 p-8 rounded-2xl text-center">
        <h3 className="text-2xl font-bold mb-4">Stay up to date</h3>
        <p className="mb-6 text-muted-foreground max-w-2xl mx-auto">
          Get the latest fitness articles, workouts, and nutrition tips delivered directly to your inbox.
        </p>
        <div className="max-w-md mx-auto flex gap-2">
          <Input placeholder="Enter your email" type="email" />
          <Button>Subscribe</Button>
        </div>
      </div>
    </div>
  );
};

export default Blog;
