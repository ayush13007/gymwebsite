
// Define the Gym interface for use across all components

export interface Gym {
  id: string;
  name: string;
  location: string;
  description?: string;
  rating?: number;
  reviewCount?: number;
  equipment?: string[];
  services?: string[];
  trainers?: string[];
  openingHours?: string;
  contactNumber?: string;
  website?: string;
  email?: string;
  currency?: string;
  socialMedia?: {
    facebook?: string;
    instagram?: string;
    twitter?: string;
  };
  images?: string[];
  coordinates?: {
    lat: number;
    lng: number;
  };
  amenities?: string[];
  classSchedule?: {
    day: string;
    classes: {
      name: string;
      time: string;
      trainer: string;
    }[];
  }[];
  membershipOptions?: {
    name: string;
    price: number;
    features: string[];
  }[];
  [key: string]: any; // For future extensibility
}
